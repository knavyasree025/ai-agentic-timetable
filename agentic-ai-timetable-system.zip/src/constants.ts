import { AIAgent, Conflict, Teacher, TimetableEntry, AdminProfile, AlertSettings, StudentAlert } from './types';

export const DEFAULT_ADMIN: AdminProfile = {
  name: 'Navya',
  email: 'k.navyasree025@gmail.com',
  role: 'Lead Timetable Administrator',
  department: 'Academic Operations & Scheduling',
  institution: 'Apex Institute of Technology & Sciences',
};

export const DEFAULT_ALERT_SETTINGS: AlertSettings = {
  autoSendOnNoClass: true,
  sendEmail: true,
  sendSMS: true,
  sendWhatsApp: true,
  studentGroups: ['Computer Science - Year 3', 'Information Tech - Year 2', 'Mechanical - Section B'],
  defaultEmailTemplate: 'Dear Student, you have NO CLASS scheduled on {DAY} at {TIME} ({REASON}). Please make productive use of this free period in the digital library or project lab.',
  defaultSMSTemplate: 'APEX ALERT: No class on {DAY} at {TIME}. Free period for {GROUP}. - Admin Navya',
  senderName: 'Admin Navya (Academic Scheduling)',
  senderEmail: 'k.navyasree025@gmail.com',
  advanceNoticeMinutes: 30,
};

export const INITIAL_STUDENT_ALERTS: StudentAlert[] = [
  {
    id: 'alert-1',
    type: 'no_class',
    day: 'Monday',
    time: '01:00 PM',
    channels: ['email', 'sms'],
    recipientsCount: 120,
    sentAt: 'Just now',
    title: 'Free Period Notice - Monday 01:00 PM',
    content: 'Automated notification dispatched by Admin Navya: No lecture scheduled for 01:00 PM on Monday. Enjoy your study break.',
    status: 'delivered',
    studentGroup: 'All Department Students'
  },
  {
    id: 'alert-2',
    type: 'cancelled_class',
    day: 'Wednesday',
    time: '03:00 PM',
    subject: 'Physics Lab',
    channels: ['email', 'sms', 'whatsapp'],
    recipientsCount: 65,
    sentAt: '10 mins ago',
    title: 'Class Update: Physics Lab Free Slot',
    content: 'Prof. Wilson faculty leave - Slot released. Students notified via email & SMS.',
    status: 'delivered',
    studentGroup: 'Computer Science - Year 3'
  }
];

export const DAYS = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];
export const BREAK_TIME_SLOT = '12:45 PM - 01:30 PM';
export const TIME_SLOTS = [
  '09:00 AM', 
  '10:00 AM', 
  '11:00 AM', 
  '12:00 PM', 
  '12:45 PM - 01:30 PM', 
  '01:30 PM', 
  '02:30 PM', 
  '03:30 PM'
];

export const MOCK_TEACHERS: Teacher[] = [
  { id: '1', name: 'Dr. Sarah Smith', subject: 'Mathematics', availability: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'] },
  { id: '2', name: 'Prof. James Wilson', subject: 'Physics & Electronics', availability: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'] },
  { id: '3', name: 'Ms. Emily Brown', subject: 'English Literature', availability: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'] },
  { id: '4', name: 'Dr. Alan Turing', subject: 'Computer Science & AI', availability: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'] },
  { id: '5', name: 'Mrs. Clara Evans', subject: 'Library & Research', availability: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'] },
  { id: '6', name: 'Prof. David Miller', subject: 'Chemistry & Materials', availability: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'] },
];

export const MOCK_AGENTS: AIAgent[] = [
  {
    id: '1',
    name: 'Scheduler Agent',
    role: 'Primary Orchestrator',
    status: 'completed',
    logs: [
      'Initializing schedule matrix...',
      'Enforcing mandatory Break: 12:45 PM - 01:30 PM across all days...',
      'Allocating Library & Research sessions in Central Library Hall...',
      'Filling full academic workload (32 active sessions, 3 designated free periods)...'
    ],
    icon: 'Bot'
  },
  {
    id: '2',
    name: 'Conflict Resolver',
    role: 'Constraint Validator',
    status: 'working',
    logs: [
      'Validating break interval (12:45 PM - 01:30 PM) is 100% free of lectures...',
      'Checking faculty subject bindings (Zero teacher-subject mismatches)...',
      'Verifying teacher load equilibrium across 5 academic days...'
    ],
    icon: 'ShieldAlert'
  },
  {
    id: '3',
    name: 'Optimization Agent',
    role: 'Efficiency Expert',
    status: 'completed',
    logs: ['Optimizing student commute intervals...', 'Balancing Library sessions with laboratory hours.'],
    icon: 'Zap'
  },
  {
    id: '4',
    name: 'Student Notification Agent',
    role: 'Automated Dispatcher (Email & SMS)',
    status: 'working',
    logs: [
      'Scanning timetable for free periods & no-class slots (3 identified)...',
      'Auto-generated email & SMS alerts configured by Admin Navya',
      'Targeting student broadcast channels (Email + SMS Gateway)...'
    ],
    icon: 'Bell'
  }
];

export const MOCK_TIMETABLE: TimetableEntry[] = [
  // Monday (All filled)
  { day: 'Monday', time: '09:00 AM', subject: 'Mathematics', teacher: 'Dr. Sarah Smith', room: 'Room 101', color: 'bg-blue-500/20 text-blue-300 border-blue-500/50' },
  { day: 'Monday', time: '10:00 AM', subject: 'Physics & Electronics', teacher: 'Prof. James Wilson', room: 'Room 102', color: 'bg-cyan-500/20 text-cyan-300 border-cyan-500/50' },
  { day: 'Monday', time: '11:00 AM', subject: 'English Literature', teacher: 'Ms. Emily Brown', room: 'Room 103', color: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/50' },
  { day: 'Monday', time: '12:00 PM', subject: 'Computer Science & AI', teacher: 'Dr. Alan Turing', room: 'AI & Computing Lab', color: 'bg-purple-500/20 text-purple-300 border-purple-500/50' },
  { day: 'Monday', time: '01:30 PM', subject: 'Chemistry & Materials', teacher: 'Prof. David Miller', room: 'Chemistry Lab', color: 'bg-rose-500/20 text-rose-300 border-rose-500/50' },
  { day: 'Monday', time: '02:30 PM', subject: 'Library & Research', teacher: 'Mrs. Clara Evans', room: 'Central Library Hall', color: 'bg-amber-500/20 text-amber-300 border-amber-500/50' },
  { day: 'Monday', time: '03:30 PM', subject: 'Mathematics', teacher: 'Dr. Sarah Smith', room: 'Room 101', color: 'bg-blue-500/20 text-blue-300 border-blue-500/50' },

  // Tuesday (6 filled, 1 free at 03:30 PM)
  { day: 'Tuesday', time: '09:00 AM', subject: 'Computer Science & AI', teacher: 'Dr. Alan Turing', room: 'AI & Computing Lab', color: 'bg-purple-500/20 text-purple-300 border-purple-500/50' },
  { day: 'Tuesday', time: '10:00 AM', subject: 'Mathematics', teacher: 'Dr. Sarah Smith', room: 'Room 101', color: 'bg-blue-500/20 text-blue-300 border-blue-500/50' },
  { day: 'Tuesday', time: '11:00 AM', subject: 'Physics & Electronics', teacher: 'Prof. James Wilson', room: 'Room 102', color: 'bg-cyan-500/20 text-cyan-300 border-cyan-500/50' },
  { day: 'Tuesday', time: '12:00 PM', subject: 'English Literature', teacher: 'Ms. Emily Brown', room: 'Room 103', color: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/50' },
  { day: 'Tuesday', time: '01:30 PM', subject: 'Chemistry & Materials', teacher: 'Prof. David Miller', room: 'Chemistry Lab', color: 'bg-rose-500/20 text-rose-300 border-rose-500/50' },
  { day: 'Tuesday', time: '02:30 PM', subject: 'Library & Research', teacher: 'Mrs. Clara Evans', room: 'Central Library Hall', color: 'bg-amber-500/20 text-amber-300 border-amber-500/50' },
  // Tuesday 03:30 PM is FREE PERIOD (1 of 3)

  // Wednesday (All filled)
  { day: 'Wednesday', time: '09:00 AM', subject: 'Physics & Electronics', teacher: 'Prof. James Wilson', room: 'Room 102', color: 'bg-cyan-500/20 text-cyan-300 border-cyan-500/50' },
  { day: 'Wednesday', time: '10:00 AM', subject: 'Mathematics', teacher: 'Dr. Sarah Smith', room: 'Room 101', color: 'bg-blue-500/20 text-blue-300 border-blue-500/50' },
  { day: 'Wednesday', time: '11:00 AM', subject: 'Computer Science & AI', teacher: 'Dr. Alan Turing', room: 'AI & Computing Lab', color: 'bg-purple-500/20 text-purple-300 border-purple-500/50' },
  { day: 'Wednesday', time: '12:00 PM', subject: 'Library & Research', teacher: 'Mrs. Clara Evans', room: 'Central Library Hall', color: 'bg-amber-500/20 text-amber-300 border-amber-500/50' },
  { day: 'Wednesday', time: '01:30 PM', subject: 'English Literature', teacher: 'Ms. Emily Brown', room: 'Room 103', color: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/50' },
  { day: 'Wednesday', time: '02:30 PM', subject: 'Chemistry & Materials', teacher: 'Prof. David Miller', room: 'Chemistry Lab', color: 'bg-rose-500/20 text-rose-300 border-rose-500/50' },
  { day: 'Wednesday', time: '03:30 PM', subject: 'Computer Science & AI', teacher: 'Dr. Alan Turing', room: 'AI & Computing Lab', color: 'bg-purple-500/20 text-purple-300 border-purple-500/50' },

  // Thursday (6 filled, 1 free at 03:30 PM)
  { day: 'Thursday', time: '09:00 AM', subject: 'English Literature', teacher: 'Ms. Emily Brown', room: 'Room 103', color: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/50' },
  { day: 'Thursday', time: '10:00 AM', subject: 'Chemistry & Materials', teacher: 'Prof. David Miller', room: 'Chemistry Lab', color: 'bg-rose-500/20 text-rose-300 border-rose-500/50' },
  { day: 'Thursday', time: '11:00 AM', subject: 'Mathematics', teacher: 'Dr. Sarah Smith', room: 'Room 101', color: 'bg-blue-500/20 text-blue-300 border-blue-500/50' },
  { day: 'Thursday', time: '12:00 PM', subject: 'Physics & Electronics', teacher: 'Prof. James Wilson', room: 'Room 102', color: 'bg-cyan-500/20 text-cyan-300 border-cyan-500/50' },
  { day: 'Thursday', time: '01:30 PM', subject: 'Library & Research', teacher: 'Mrs. Clara Evans', room: 'Central Library Hall', color: 'bg-amber-500/20 text-amber-300 border-amber-500/50' },
  { day: 'Thursday', time: '02:30 PM', subject: 'Computer Science & AI', teacher: 'Dr. Alan Turing', room: 'AI & Computing Lab', color: 'bg-purple-500/20 text-purple-300 border-purple-500/50' },
  // Thursday 03:30 PM is FREE PERIOD (2 of 3)

  // Friday (6 filled, 1 free at 03:30 PM)
  { day: 'Friday', time: '09:00 AM', subject: 'Mathematics', teacher: 'Dr. Sarah Smith', room: 'Room 101', color: 'bg-blue-500/20 text-blue-300 border-blue-500/50' },
  { day: 'Friday', time: '10:00 AM', subject: 'Computer Science & AI', teacher: 'Dr. Alan Turing', room: 'AI & Computing Lab', color: 'bg-purple-500/20 text-purple-300 border-purple-500/50' },
  { day: 'Friday', time: '11:00 AM', subject: 'Chemistry & Materials', teacher: 'Prof. David Miller', room: 'Chemistry Lab', color: 'bg-rose-500/20 text-rose-300 border-rose-500/50' },
  { day: 'Friday', time: '12:00 PM', subject: 'Physics & Electronics', teacher: 'Prof. James Wilson', room: 'Room 102', color: 'bg-cyan-500/20 text-cyan-300 border-cyan-500/50' },
  { day: 'Friday', time: '01:30 PM', subject: 'Library & Research', teacher: 'Mrs. Clara Evans', room: 'Central Library Hall', color: 'bg-amber-500/20 text-amber-300 border-amber-500/50' },
  { day: 'Friday', time: '02:30 PM', subject: 'English Literature', teacher: 'Ms. Emily Brown', room: 'Room 103', color: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/50' },
  // Friday 03:30 PM is FREE PERIOD (3 of 3)
];

export const MOCK_CONFLICTS: Conflict[] = [
  {
    id: 'c1',
    type: 'clash',
    description: 'Room 101 is double-booked for Math and Science at 10:00 AM on Tuesday.',
    severity: 'high',
    suggestions: ['Move Science to Room 102', 'Reschedule Math to 11:00 AM']
  },
  {
    id: 'c2',
    type: 'availability',
    description: 'Dr. Sarah Smith is not available on Tuesday mornings.',
    severity: 'medium',
    suggestions: ['Assign substitute teacher', 'Swap with Wednesday slot']
  }
];
