export type Screen = 'landing' | 'input' | 'dashboard' | 'timetable' | 'conflicts' | 'settings';

export interface AdminProfile {
  name: string;
  email: string;
  role: string;
  department: string;
  institution: string;
  avatarUrl?: string;
}

export interface StudentAlert {
  id: string;
  type: 'no_class' | 'cancelled_class' | 'free_period' | 'rescheduled';
  day: string;
  time: string;
  subject?: string;
  room?: string;
  channels: ('email' | 'sms' | 'whatsapp')[];
  recipientsCount: number;
  sentAt: string;
  title: string;
  content: string;
  status: 'delivered' | 'sending' | 'queued';
  studentGroup: string;
}

export interface AlertSettings {
  autoSendOnNoClass: boolean;
  sendEmail: boolean;
  sendSMS: boolean;
  sendWhatsApp: boolean;
  studentGroups: string[];
  defaultEmailTemplate: string;
  defaultSMSTemplate: string;
  senderName: string;
  senderEmail: string;
  advanceNoticeMinutes: number;
}

export interface Teacher {
  id: string;
  name: string;
  subject: string;
  availability: string[];
}

export interface Classroom {
  id: string;
  name: string;
}

export interface Subject {
  id: string;
  name: string;
}

export interface TimetableEntry {
  day: string;
  time: string;
  subject: string;
  teacher: string;
  room: string;
  color: string;
  isNoClass?: boolean;
}

export interface AIAgent {
  id: string;
  name: string;
  role: string;
  status: 'idle' | 'working' | 'completed' | 'error';
  logs: string[];
  icon: string;
}

export interface Conflict {
  id: string;
  type: 'clash' | 'availability' | 'preference';
  description: string;
  severity: 'high' | 'medium' | 'low';
  suggestions: string[];
}
