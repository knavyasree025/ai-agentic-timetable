import { useState } from 'react';
import { Bell, Search, User, Mail, MessageSquare, CheckCircle2, Send, ShieldCheck, Sparkles, X, ExternalLink } from 'lucide-react';
import { AdminProfile, StudentAlert, AlertSettings } from '../types';

interface TopNavProps {
  admin: AdminProfile;
  alerts: StudentAlert[];
  alertSettings: AlertSettings;
  onOpenSettings?: () => void;
  onClearAlerts?: () => void;
  onSendInstantAlert?: (alert: Omit<StudentAlert, 'id' | 'sentAt' | 'status'>) => void;
}

export default function TopNav({ admin, alerts, alertSettings, onOpenSettings, onClearAlerts, onSendInstantAlert }: TopNavProps) {
  const [showNotifications, setShowNotifications] = useState(false);
  const [showProfileModal, setShowProfileModal] = useState(false);
  const [quickSearch, setQuickSearch] = useState('');

  const unreadCount = alerts.filter(a => a.status === 'delivered' || a.status === 'sending').length;

  return (
    <header className="h-20 px-8 flex items-center justify-between glass border-t-0 border-x-0 sticky top-0 z-40">
      {/* Search bar */}
      <div className="flex items-center gap-4 bg-white/5 px-4 py-2 rounded-full border border-white/10 w-80 md:w-96 focus-within:border-blue-500/50 transition-all">
        <Search size={18} className="text-slate-400" />
        <input 
          type="text" 
          value={quickSearch}
          onChange={(e) => setQuickSearch(e.target.value)}
          placeholder="Search schedules, teachers, free periods..." 
          className="bg-transparent border-none outline-none text-sm w-full text-slate-200 placeholder:text-slate-500"
        />
      </div>

      {/* Right controls */}
      <div className="flex items-center gap-5">
        {/* Auto alert indicator badge */}
        {alertSettings.autoSendOnNoClass && (
          <div className="hidden lg:flex items-center gap-2 px-3 py-1.5 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs font-semibold">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span>Auto-Alert Students: Active</span>
          </div>
        )}

        {/* Notifications Bell */}
        <div className="relative">
          <button 
            onClick={() => setShowNotifications(!showNotifications)}
            className="relative p-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white transition-all border border-white/5"
            title="Student Notifications & Auto-Alerts"
          >
            <Bell size={20} />
            {unreadCount > 0 && (
              <span className="absolute -top-1 -right-1 px-1.5 py-0.5 min-w-[20px] h-5 bg-blue-600 text-[10px] font-bold text-white rounded-full flex items-center justify-center border-2 border-slate-950 animate-pulse shadow-lg shadow-blue-500/50">
                {unreadCount}
              </span>
            )}
          </button>

          {/* Notifications Dropdown Drawer */}
          {showNotifications && (
            <div className="absolute right-0 mt-3 w-96 glass rounded-2xl border border-white/10 shadow-2xl p-4 z-50 animate-in fade-in slide-in-from-top-2 duration-200">
              <div className="flex items-center justify-between pb-3 border-b border-white/10">
                <div className="flex items-center gap-2">
                  <Mail size={16} className="text-blue-400" />
                  <h4 className="font-bold text-sm text-slate-100">Student Notification Dispatch</h4>
                </div>
                <div className="flex items-center gap-2">
                  {onClearAlerts && alerts.length > 0 && (
                    <button 
                      onClick={onClearAlerts}
                      className="text-[11px] text-slate-400 hover:text-slate-200 underline"
                    >
                      Clear
                    </button>
                  )}
                  <button 
                    onClick={() => setShowNotifications(false)}
                    className="p-1 hover:bg-white/10 rounded-lg text-slate-400 hover:text-white"
                  >
                    <X size={14} />
                  </button>
                </div>
              </div>

              {/* Status summary banner */}
              <div className="my-3 p-2.5 rounded-xl bg-blue-600/10 border border-blue-500/20 text-xs text-blue-300 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Sparkles size={14} className="text-blue-400" />
                  <span>Admin <strong>{admin.name}</strong> Auto-Dispatch</span>
                </div>
                <span className="text-[10px] px-2 py-0.5 bg-blue-500/20 rounded-full font-mono">Email + SMS</span>
              </div>

              {/* List of alerts */}
              <div className="space-y-2.5 max-h-72 overflow-y-auto pr-1">
                {alerts.length === 0 ? (
                  <div className="text-center py-6 text-slate-400 text-xs">
                    <p>No recent student notifications.</p>
                    <p className="text-[10px] text-slate-500 mt-1">Free period and no-class alerts will appear here automatically.</p>
                  </div>
                ) : (
                  alerts.map((alert) => (
                    <div key={alert.id} className="p-3 bg-white/5 rounded-xl border border-white/5 hover:border-white/10 transition-all text-xs">
                      <div className="flex items-center justify-between mb-1">
                        <span className="font-bold text-slate-200 flex items-center gap-1.5">
                          {alert.type === 'no_class' ? (
                            <span className="w-2 h-2 rounded-full bg-amber-400" />
                          ) : (
                            <span className="w-2 h-2 rounded-full bg-blue-400" />
                          )}
                          {alert.title}
                        </span>
                        <span className="text-[10px] text-slate-500">{alert.sentAt}</span>
                      </div>
                      <p className="text-slate-300 text-[11px] mb-2 leading-relaxed">{alert.content}</p>
                      <div className="flex items-center justify-between text-[10px] text-slate-400 pt-1 border-t border-white/5">
                        <div className="flex items-center gap-2">
                          <span className="flex items-center gap-1 text-emerald-400 font-medium">
                            <CheckCircle2 size={10} /> {alert.recipientsCount} Students Notified
                          </span>
                        </div>
                        <div className="flex gap-1.5">
                          {alert.channels.map(ch => (
                            <span key={ch} className="px-1.5 py-0.5 bg-white/10 rounded uppercase tracking-wider text-[9px]">
                              {ch}
                            </span>
                          ))}
                        </div>
                      </div>
                    </div>
                  ))
                )}
              </div>

              <div className="mt-3 pt-3 border-t border-white/10 flex items-center justify-between">
                <span className="text-[11px] text-slate-400">Recipient: <strong>All Enrolled Batches</strong></span>
                {onOpenSettings && (
                  <button 
                    onClick={() => {
                      setShowNotifications(false);
                      onOpenSettings();
                    }}
                    className="text-[11px] font-bold text-blue-400 hover:text-blue-300 flex items-center gap-1"
                  >
                    Alert Settings <ExternalLink size={12} />
                  </button>
                )}
              </div>
            </div>
          )}
        </div>
        
        <div className="h-8 w-[1px] bg-white/10" />

        {/* User Profile - Admin Navya */}
        <div className="relative">
          <button 
            onClick={() => setShowProfileModal(!showProfileModal)}
            className="flex items-center gap-3 pl-2 p-1.5 rounded-2xl hover:bg-white/5 transition-all text-left group"
          >
            <div className="text-right hidden sm:block">
              <div className="flex items-center justify-end gap-1.5">
                <span className="text-sm font-bold text-white group-hover:text-blue-300 transition-colors">
                  {admin.name}
                </span>
                <ShieldCheck size={14} className="text-blue-400" />
              </div>
              <p className="text-[11px] text-slate-400 font-medium">{admin.role}</p>
            </div>
            
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-blue-600 to-cyan-500 flex items-center justify-center border border-white/20 shadow-lg shadow-blue-500/20 group-hover:scale-105 transition-transform">
              <span className="text-white font-bold text-sm tracking-wider">
                {admin.name.slice(0, 2).toUpperCase()}
              </span>
            </div>
          </button>

          {/* Profile Dropdown */}
          {showProfileModal && (
            <div className="absolute right-0 mt-3 w-80 glass rounded-2xl border border-white/10 shadow-2xl p-5 z-50 animate-in fade-in slide-in-from-top-2 duration-200">
              <div className="flex items-center gap-3 pb-4 border-b border-white/10">
                <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-blue-600 to-cyan-500 flex items-center justify-center text-white font-bold text-lg shadow-lg">
                  {admin.name.slice(0, 2).toUpperCase()}
                </div>
                <div>
                  <h4 className="font-bold text-slate-100 flex items-center gap-1.5">
                    {admin.name} <span className="text-[10px] px-2 py-0.5 rounded-full bg-blue-500/20 text-blue-400 font-normal">Admin</span>
                  </h4>
                  <p className="text-xs text-slate-400 font-mono">{admin.email}</p>
                </div>
              </div>

              <div className="py-3 space-y-2 text-xs">
                <div className="flex justify-between py-1 border-b border-white/5">
                  <span className="text-slate-400">Department</span>
                  <span className="text-slate-200 font-medium">{admin.department}</span>
                </div>
                <div className="flex justify-between py-1 border-b border-white/5">
                  <span className="text-slate-400">Institution</span>
                  <span className="text-slate-200 font-medium truncate max-w-[160px]">{admin.institution}</span>
                </div>
                <div className="flex justify-between py-1">
                  <span className="text-slate-400">Free Slot Alerts</span>
                  <span className="text-emerald-400 font-semibold flex items-center gap-1">
                    <CheckCircle2 size={12} /> Auto-Broadcast
                  </span>
                </div>
              </div>

              <div className="pt-3 border-t border-white/10">
                <button 
                  onClick={() => {
                    setShowProfileModal(false);
                    if (onOpenSettings) onOpenSettings();
                  }}
                  className="w-full py-2.5 px-4 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-bold transition-all text-center flex items-center justify-center gap-2"
                >
                  Manage Admin & Notification Settings
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}
