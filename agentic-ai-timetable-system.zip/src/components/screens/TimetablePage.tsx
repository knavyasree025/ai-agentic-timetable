import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Download, 
  RefreshCw, 
  Filter, 
  Share2, 
  Printer, 
  ChevronLeft, 
  ChevronRight, 
  Mail, 
  MessageSquare, 
  Send, 
  CheckCircle2, 
  Sparkles, 
  Coffee, 
  X, 
  BellRing,
  AlertCircle,
  Eye,
  UtensilsCrossed
} from 'lucide-react';
import { DAYS, TIME_SLOTS, BREAK_TIME_SLOT } from '../../constants';
import { TimetableEntry, StudentAlert, AlertSettings, AdminProfile } from '../../types';

interface TimetablePageProps {
  timetable: TimetableEntry[];
  admin: AdminProfile;
  alertSettings: AlertSettings;
  onRegenerate: () => void;
  onSendAlert: (alert: Omit<StudentAlert, 'id' | 'sentAt' | 'status'>) => void;
}

export default function TimetablePage({ timetable, admin, alertSettings, onRegenerate, onSendAlert }: TimetablePageProps) {
  const [selectedSlot, setSelectedSlot] = useState<{ day: string; time: string; entry?: TimetableEntry } | null>(null);
  const [showDispatchModal, setShowDispatchModal] = useState(false);
  const [customReason, setCustomReason] = useState('Faculty Seminar / Self-Study Hour');
  const [channelEmail, setChannelEmail] = useState(true);
  const [channelSMS, setChannelSMS] = useState(true);
  const [channelWhatsApp, setChannelWhatsApp] = useState(true);
  const [selectedGroup, setSelectedGroup] = useState('All Enrolled Students (Batch 2026)');
  const [dispatchSuccess, setDispatchSuccess] = useState(false);
  const [filterMode, setFilterMode] = useState<'all' | 'classes' | 'free'>('all');

  // Count empty slots (excluding mandatory 12:45 - 1:30 PM Lunch break)
  const totalAcademicSlots = DAYS.length * (TIME_SLOTS.length - 1);
  const filledSlotsCount = timetable.length;
  const freeSlotsCount = Math.max(0, totalAcademicSlots - filledSlotsCount);

  const handleOpenAlertForSlot = (day: string, time: string, entry?: TimetableEntry) => {
    setSelectedSlot({ day, time, entry });
    setDispatchSuccess(false);
    setShowDispatchModal(true);
  };

  const handleDispatchNow = () => {
    if (!selectedSlot) return;
    const channels: ('email' | 'sms' | 'whatsapp')[] = [];
    if (channelEmail) channels.push('email');
    if (channelSMS) channels.push('sms');
    if (channelWhatsApp) channels.push('whatsapp');

    const isFree = !selectedSlot.entry;
    const title = isFree 
      ? `Free Period Notice: ${selectedSlot.day} @ ${selectedSlot.time}`
      : `Class Notice: ${selectedSlot.entry?.subject} on ${selectedSlot.day} @ ${selectedSlot.time}`;

    const content = isFree
      ? `Official alert from Admin ${admin.name}: No class is scheduled on ${selectedSlot.day} at ${selectedSlot.time} (${customReason}). Students are advised to utilize the campus library or project labs.`
      : `Official notice from Admin ${admin.name}: Class ${selectedSlot.entry?.subject} in ${selectedSlot.entry?.room} with ${selectedSlot.entry?.teacher}.`;

    onSendAlert({
      type: isFree ? 'no_class' : 'rescheduled',
      day: selectedSlot.day,
      time: selectedSlot.time,
      subject: selectedSlot.entry?.subject,
      room: selectedSlot.entry?.room,
      channels,
      recipientsCount: 145,
      title,
      content,
      studentGroup: selectedGroup
    });

    setDispatchSuccess(true);
    setTimeout(() => {
      setShowDispatchModal(false);
      setDispatchSuccess(false);
    }, 1800);
  };

  const [broadcastToast, setBroadcastToast] = useState<string | null>(null);

  const handleBroadcastAllFreeSlots = () => {
    onSendAlert({
      type: 'free_period',
      day: 'All Week',
      time: 'Multiple Slots',
      channels: ['email', 'sms'],
      recipientsCount: 350,
      title: `Weekly Free Period Digest (${freeSlotsCount} Slots)`,
      content: `Admin ${admin.name} has dispatched the weekly free-period timetable updates. All ${freeSlotsCount} unscheduled slots are now mapped to open study centers.`,
      studentGroup: 'All Academic Batches'
    });
    setBroadcastToast(`Broadcast dispatched! Auto-Email and SMS notifications sent to 350 students across all ${freeSlotsCount} free periods by Admin ${admin.name}.`);
    setTimeout(() => setBroadcastToast(null), 4000);
  };

  return (
    <div className="p-8 max-w-[1600px] mx-auto">
      {/* Toast Notification */}
      <AnimatePresence>
        {broadcastToast && (
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="mb-6 p-4 rounded-2xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-200 text-sm flex items-center justify-between shadow-xl"
          >
            <div className="flex items-center gap-2.5">
              <CheckCircle2 size={18} className="text-emerald-400" />
              <span>{broadcastToast}</span>
            </div>
            <button onClick={() => setBroadcastToast(null)} className="text-emerald-400 hover:text-white p-1">
              <X size={16} />
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Header */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 mb-8">
        <div>
          <div className="flex items-center gap-3 mb-2">
            <h2 className="text-3xl font-display font-bold">Academic Timetable Matrix</h2>
            <span className="px-3 py-1 bg-blue-500/20 text-blue-300 border border-blue-500/30 rounded-full text-xs font-semibold">
              Admin: {admin.name}
            </span>
          </div>
          <p className="text-slate-400 text-sm">
            AI-orchestrated schedule with automated student mail & message dispatch for free periods.
          </p>
        </div>
        
        <div className="flex flex-wrap items-center gap-3">
          {/* Filter Mode */}
          <div className="flex bg-white/5 p-1 rounded-xl border border-white/10">
            <button 
              onClick={() => setFilterMode('all')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${filterMode === 'all' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white'}`}
            >
              All Slots ({totalAcademicSlots})
            </button>
            <button 
              onClick={() => setFilterMode('classes')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${filterMode === 'classes' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white'}`}
            >
              Classes ({filledSlotsCount})
            </button>
            <button 
              onClick={() => setFilterMode('free')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${filterMode === 'free' ? 'bg-amber-500/30 text-amber-300' : 'text-slate-400 hover:text-white'}`}
            >
              Free Periods ({freeSlotsCount})
            </button>
          </div>

          <button 
            onClick={onRegenerate}
            className="px-4 py-2 glass rounded-xl text-sm font-semibold flex items-center gap-2 hover:bg-white/10 transition-all text-slate-200"
          >
            <RefreshCw size={16} /> Regenerate
          </button>
          
          <button 
            onClick={handleBroadcastAllFreeSlots}
            className="px-4 py-2 bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-500 hover:to-orange-500 rounded-xl text-sm font-bold flex items-center gap-2 transition-all shadow-lg shadow-amber-600/20 text-white"
          >
            <BellRing size={16} /> Broadcast All Free Slots
          </button>

          <button className="px-5 py-2 bg-blue-600 rounded-xl text-sm font-bold flex items-center gap-2 hover:bg-blue-500 transition-all shadow-lg shadow-blue-600/20 text-white">
            <Download size={16} /> Export PDF
          </button>
        </div>
      </div>

      {/* Automated Student Alert Banner */}
      <div className="mb-8 p-4 rounded-2xl bg-gradient-to-r from-blue-900/40 via-indigo-900/30 to-purple-900/40 border border-blue-500/30 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-blue-600/30 border border-blue-400/30 flex items-center justify-center text-blue-300">
            <Mail size={20} />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-sm font-bold text-white">Automated Student Alerts Engine: Active</span>
              <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 text-[10px] font-mono">
                {alertSettings.autoSendOnNoClass ? 'AUTO-DISPATCH ON' : 'MANUAL'}
              </span>
            </div>
            <p className="text-xs text-slate-300">
              When there is <strong>No Class</strong> in a time slot, students receive instant Email (<span className="text-blue-300">{alertSettings.senderEmail}</span>) & SMS alerts automatically. Click any slot to dispatch custom notifications.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0 text-xs text-slate-300 font-medium">
          <span className="px-3 py-1.5 rounded-xl bg-black/30 border border-white/10 flex items-center gap-1.5">
            <MessageSquare size={14} className="text-cyan-400" /> SMS / WhatsApp Ready
          </span>
        </div>
      </div>

      {/* Timetable Grid */}
      <div className="glass rounded-[32px] overflow-hidden border border-white/10 shadow-2xl">
        <div className="overflow-x-auto">
          <table className="w-full border-collapse">
            <thead>
              <tr>
                <th className="p-5 bg-white/5 border-b border-r border-white/10 w-32">
                  <div className="flex items-center justify-center gap-2 text-slate-400">
                    <ChevronLeft size={16} />
                    <span className="text-xs font-bold uppercase tracking-widest">Time</span>
                    <ChevronRight size={16} />
                  </div>
                </th>
                {DAYS.map(day => (
                  <th key={day} className="p-5 bg-white/5 border-b border-white/10 min-w-[210px]">
                    <span className="text-lg font-display font-bold text-slate-200">{day}</span>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {TIME_SLOTS.map(time => {
                const isBreak = time === BREAK_TIME_SLOT;

                if (isBreak) {
                  return (
                    <tr key={time} className="bg-amber-500/[0.07] border-y-2 border-amber-500/30">
                      <td className="p-4 border-r border-amber-500/20 text-center bg-amber-500/10">
                        <div className="flex flex-col items-center">
                          <span className="text-xs font-bold text-amber-300">12:45 PM</span>
                          <span className="text-[10px] text-amber-400/80">to 01:30 PM</span>
                          <span className="mt-1 px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300 text-[9px] font-bold uppercase tracking-wider">
                            Break
                          </span>
                        </div>
                      </td>
                      <td colSpan={DAYS.length} className="p-4 text-center">
                        <div className="flex items-center justify-between px-4 py-2 rounded-2xl bg-gradient-to-r from-amber-500/15 via-orange-500/15 to-amber-500/15 border border-amber-500/30">
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-10 rounded-xl bg-amber-500/20 text-amber-300 flex items-center justify-center border border-amber-500/40 shrink-0">
                              <UtensilsCrossed size={20} />
                            </div>
                            <div className="text-left">
                              <div className="flex items-center gap-2">
                                <h4 className="font-display font-bold text-amber-200 text-sm tracking-wide">
                                  LUNCH & RECESS BREAK (12:45 PM - 01:30 PM)
                                </h4>
                                <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 text-[10px] font-semibold border border-emerald-500/30">
                                  Campus Dining Active
                                </span>
                              </div>
                              <p className="text-xs text-amber-300/80">
                                Mandatory institutional break enforced by Admin {admin.name}. Zero classes scheduled across all faculty and batches.
                              </p>
                            </div>
                          </div>
                          <div className="hidden sm:flex items-center gap-3 text-xs text-amber-200/90 font-medium">
                            <span className="px-3 py-1.5 rounded-xl bg-black/30 border border-amber-500/20 flex items-center gap-1.5">
                              <Coffee size={14} className="text-amber-400" /> 45 Minutes Interval
                            </span>
                          </div>
                        </div>
                      </td>
                    </tr>
                  );
                }

                return (
                  <tr key={time}>
                    <td className="p-4 border-r border-b border-white/10 text-center bg-white/[0.02]">
                      <span className="text-xs font-bold text-slate-400">{time}</span>
                    </td>
                    {DAYS.map(day => {
                      const entry = timetable.find(e => e.day === day && e.time === time);
                      const isVisible = 
                        filterMode === 'all' ? true :
                        filterMode === 'classes' ? !!entry :
                        filterMode === 'free' ? !entry : true;

                      if (!isVisible) {
                        return (
                          <td key={`${day}-${time}`} className="p-2 border-b border-white/10 min-h-[110px] opacity-20">
                            <div className="h-full min-h-[90px] rounded-2xl bg-white/[0.02] border border-white/5" />
                          </td>
                        );
                      }

                      return (
                        <td key={`${day}-${time}`} className="p-2.5 border-b border-white/10 min-h-[120px] align-top">
                          {entry ? (
                            <motion.div 
                              layoutId={`${entry.day}-${entry.time}-${entry.subject}`}
                              initial={{ opacity: 0, scale: 0.95 }}
                              animate={{ opacity: 1, scale: 1 }}
                              onClick={() => handleOpenAlertForSlot(day, time, entry)}
                              className={`p-3.5 rounded-2xl border ${entry.color} h-full flex flex-col justify-between group cursor-pointer hover:brightness-110 hover:shadow-lg transition-all relative`}
                            >
                              <div>
                                <div className="flex items-center justify-between mb-1.5">
                                  <h4 className="font-bold text-sm tracking-tight">{entry.subject}</h4>
                                  <div className="w-2 h-2 rounded-full bg-current opacity-60" />
                                </div>
                                <p className="text-[11px] font-medium opacity-85 mb-1">{entry.teacher}</p>
                              </div>
                              <div className="flex items-center justify-between mt-3 pt-2 border-t border-current/10">
                                <span className="text-[10px] font-bold px-2 py-0.5 bg-black/30 rounded-md border border-white/10">
                                  {entry.room}
                                </span>
                                <span className="text-[9px] opacity-0 group-hover:opacity-100 transition-opacity font-semibold flex items-center gap-1">
                                  <Mail size={10} /> Notify
                                </span>
                              </div>
                            </motion.div>
                          ) : (
                            /* No Class / Free Period Card */
                            <div 
                              onClick={() => handleOpenAlertForSlot(day, time)}
                              className="p-3 rounded-2xl border border-dashed border-amber-500/30 bg-amber-500/[0.04] hover:bg-amber-500/[0.1] hover:border-amber-400/60 transition-all cursor-pointer flex flex-col justify-between min-h-[100px] group relative"
                            >
                              <div>
                                <div className="flex items-center justify-between mb-1">
                                  <span className="text-xs font-bold text-amber-300/90 flex items-center gap-1.5">
                                    <Coffee size={13} className="text-amber-400" /> No Class
                                  </span>
                                  <span className="text-[9px] px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300 font-mono">
                                    FREE
                                  </span>
                                </div>
                                <p className="text-[10px] text-slate-400 font-normal">Self-Study / Library</p>
                              </div>

                              <div className="mt-2 pt-1.5 border-t border-amber-500/10 flex items-center justify-between">
                                <div className="flex items-center gap-1 text-[9px] text-emerald-400 font-medium">
                                  <CheckCircle2 size={10} /> Auto-Mailed
                                </div>
                                <button 
                                  className="text-[10px] px-2 py-0.5 rounded bg-amber-500/20 text-amber-200 group-hover:bg-amber-500 group-hover:text-black font-bold transition-all flex items-center gap-1"
                                >
                                  <Send size={9} /> Alert
                                </button>
                              </div>
                            </div>
                          )}
                        </td>
                      );
                    })}
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Stats Summary */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mt-8">
        {[
          { label: 'Scheduled Lectures', value: `${filledSlotsCount} hrs`, sub: 'Active class slots' },
          { label: 'Free Periods (No Class)', value: `${freeSlotsCount} hrs`, sub: 'Auto-alerts enabled' },
          { label: 'Student Delivery Rate', value: '99.8%', sub: 'Email & SMS gateway' },
          { label: 'Active Administrator', value: admin.name, sub: admin.email }
        ].map((stat, i) => (
          <div key={i} className="glass p-6 rounded-3xl border border-white/5">
            <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-1">{stat.label}</p>
            <div className="flex items-baseline gap-2">
              <span className="text-2xl lg:text-3xl font-display font-bold text-blue-400">{stat.value}</span>
            </div>
            <span className="text-xs text-slate-500 mt-1 block truncate">{stat.sub}</span>
          </div>
        ))}
      </div>

      {/* Modal for Slot Student Notification Dispatch */}
      <AnimatePresence>
        {showDispatchModal && selectedSlot && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 10 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 10 }}
              className="w-full max-w-xl glass rounded-3xl border border-white/10 p-7 shadow-2xl relative"
            >
              {/* Header */}
              <div className="flex items-center justify-between pb-4 border-b border-white/10 mb-5">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-blue-600/30 border border-blue-500/40 flex items-center justify-center text-blue-400">
                    <Mail size={20} />
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-white">
                      {selectedSlot.entry ? `Notify Students for ${selectedSlot.entry.subject}` : `Dispatch "No Class" Alert`}
                    </h3>
                    <p className="text-xs text-slate-400">
                      {selectedSlot.day} at {selectedSlot.time} • Sender: <strong>Admin {admin.name}</strong>
                    </p>
                  </div>
                </div>
                <button 
                  onClick={() => setShowDispatchModal(false)}
                  className="p-1.5 rounded-xl hover:bg-white/10 text-slate-400 hover:text-white transition-colors"
                >
                  <X size={18} />
                </button>
              </div>

              {dispatchSuccess ? (
                <div className="py-8 text-center space-y-3">
                  <div className="w-16 h-16 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto border border-emerald-500/40">
                    <CheckCircle2 size={36} />
                  </div>
                  <h4 className="text-xl font-bold text-white">Broadcast Successfully Delivered!</h4>
                  <p className="text-xs text-slate-300 max-w-md mx-auto">
                    Email sent to student inbox and SMS alert sent to registered mobile numbers by Admin {admin.name}.
                  </p>
                </div>
              ) : (
                <div className="space-y-4 text-xs">
                  {/* Free period / class reason */}
                  {!selectedSlot.entry && (
                    <div>
                      <label className="block font-bold text-slate-300 mb-1">Reason / Activity for Free Period</label>
                      <input 
                        type="text" 
                        value={customReason}
                        onChange={(e) => setCustomReason(e.target.value)}
                        placeholder="e.g. Faculty Leave / Library Study Hour / Exam Prep"
                        className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 outline-none focus:border-blue-500 text-slate-100"
                      />
                    </div>
                  )}

                  {/* Student Target Group */}
                  <div>
                    <label className="block font-bold text-slate-300 mb-1">Target Student Batch</label>
                    <select 
                      value={selectedGroup}
                      onChange={(e) => setSelectedGroup(e.target.value)}
                      className="w-full bg-slate-900 border border-white/10 rounded-xl px-4 py-2.5 outline-none focus:border-blue-500 text-slate-200"
                    >
                      <option>All Enrolled Students (Batch 2026) - 145 Students</option>
                      <option>Computer Science - 3rd Year (Section A & B)</option>
                      <option>Information Technology - 2nd Year</option>
                      <option>Class Representatives & Department Faculty</option>
                    </select>
                  </div>

                  {/* Notification Channels */}
                  <div>
                    <label className="block font-bold text-slate-300 mb-2">Automated Dispatch Channels</label>
                    <div className="grid grid-cols-3 gap-3">
                      <label className={`p-3 rounded-xl border flex items-center gap-2.5 cursor-pointer transition-all ${channelEmail ? 'bg-blue-600/20 border-blue-500/50 text-blue-300' : 'bg-white/5 border-white/10 text-slate-400'}`}>
                        <input 
                          type="checkbox" 
                          checked={channelEmail}
                          onChange={(e) => setChannelEmail(e.target.checked)}
                          className="accent-blue-500"
                        />
                        <div>
                          <p className="font-bold">Email</p>
                          <p className="text-[10px] opacity-75">Direct to inbox</p>
                        </div>
                      </label>

                      <label className={`p-3 rounded-xl border flex items-center gap-2.5 cursor-pointer transition-all ${channelSMS ? 'bg-cyan-600/20 border-cyan-500/50 text-cyan-300' : 'bg-white/5 border-white/10 text-slate-400'}`}>
                        <input 
                          type="checkbox" 
                          checked={channelSMS}
                          onChange={(e) => setChannelSMS(e.target.checked)}
                          className="accent-cyan-500"
                        />
                        <div>
                          <p className="font-bold">SMS</p>
                          <p className="text-[10px] opacity-75">Mobile alert</p>
                        </div>
                      </label>

                      <label className={`p-3 rounded-xl border flex items-center gap-2.5 cursor-pointer transition-all ${channelWhatsApp ? 'bg-emerald-600/20 border-emerald-500/50 text-emerald-300' : 'bg-white/5 border-white/10 text-slate-400'}`}>
                        <input 
                          type="checkbox" 
                          checked={channelWhatsApp}
                          onChange={(e) => setChannelWhatsApp(e.target.checked)}
                          className="accent-emerald-500"
                        />
                        <div>
                          <p className="font-bold">WhatsApp</p>
                          <p className="text-[10px] opacity-75">Instant message</p>
                        </div>
                      </label>
                    </div>
                  </div>

                  {/* Live Email & SMS Preview */}
                  <div className="p-3.5 rounded-2xl bg-black/40 border border-white/10 space-y-2 font-mono text-[11px]">
                    <div className="flex items-center justify-between text-slate-400 pb-1.5 border-b border-white/5">
                      <span>Preview (From: {admin.name} &lt;{admin.email}&gt;)</span>
                      <span className="text-[10px] text-emerald-400 font-sans font-semibold">Ready to send</span>
                    </div>
                    <p className="text-slate-200">
                      <strong>Subject:</strong> [APEX ACADEMIC] {selectedSlot.entry ? `Update: ${selectedSlot.entry.subject}` : `NO CLASS SCHEDULED: ${selectedSlot.day} @ ${selectedSlot.time}`}
                    </p>
                    <p className="text-slate-400 leading-relaxed">
                      "Dear Student, this is an automated announcement from Admin {admin.name}. You have {selectedSlot.entry ? `class ${selectedSlot.entry.subject} scheduled in ${selectedSlot.entry.room}` : `NO CLASS on ${selectedSlot.day} at ${selectedSlot.time} (${customReason})`}. Please make use of campus facilities."
                    </p>
                  </div>

                  {/* Actions */}
                  <div className="flex items-center justify-end gap-3 pt-3 border-t border-white/10">
                    <button 
                      onClick={() => setShowDispatchModal(false)}
                      className="px-4 py-2.5 rounded-xl hover:bg-white/5 text-slate-300 font-semibold transition-colors"
                    >
                      Cancel
                    </button>
                    <button 
                      onClick={handleDispatchNow}
                      className="px-6 py-2.5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl font-bold flex items-center gap-2 transition-all shadow-lg shadow-blue-600/30"
                    >
                      <Send size={15} /> Dispatch Email & Message
                    </button>
                  </div>
                </div>
              )}
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
