import React, { useState } from 'react';
import { motion } from 'motion/react';
import { 
  Save, 
  User, 
  BookOpen, 
  Clock, 
  Shield, 
  Bell, 
  Globe, 
  Trash2, 
  Edit2, 
  Mail, 
  MessageSquare, 
  CheckCircle2, 
  Send, 
  Sparkles, 
  Building2, 
  Phone, 
  Check, 
  Layers
} from 'lucide-react';
import { Teacher, AdminProfile, AlertSettings, StudentAlert } from '../../types';

interface SettingsPageProps {
  teachers: Teacher[];
  onAddTeacher: (teacher: Teacher) => void;
  onRemoveTeacher: (id: string) => void;
  admin: AdminProfile;
  onUpdateAdmin: (admin: AdminProfile) => void;
  alertSettings: AlertSettings;
  onUpdateAlertSettings: (settings: AlertSettings) => void;
  alerts: StudentAlert[];
  onSendTestAlert: (alert: Omit<StudentAlert, 'id' | 'sentAt' | 'status'>) => void;
}

export default function SettingsPage({ 
  teachers, 
  onAddTeacher, 
  onRemoveTeacher,
  admin,
  onUpdateAdmin,
  alertSettings,
  onUpdateAlertSettings,
  alerts,
  onSendTestAlert
}: SettingsPageProps) {
  const [activeTab, setActiveTab] = useState<'teachers' | 'constraints' | 'notifications' | 'profile'>('notifications');
  const [isAddingTeacher, setIsAddingTeacher] = useState(false);
  const [name, setName] = useState('');
  const [subject, setSubject] = useState('');

  // Admin Profile form state
  const [adminName, setAdminName] = useState(admin.name);
  const [adminEmail, setAdminEmail] = useState(admin.email);
  const [adminRole, setAdminRole] = useState(admin.role);
  const [adminDept, setAdminDept] = useState(admin.department);
  const [adminInst, setAdminInst] = useState(admin.institution);
  const [profileSaved, setProfileSaved] = useState(false);

  // Notification settings state
  const [autoSendNoClass, setAutoSendNoClass] = useState(alertSettings.autoSendOnNoClass);
  const [sendEmail, setSendEmail] = useState(alertSettings.sendEmail);
  const [sendSMS, setSendSMS] = useState(alertSettings.sendSMS);
  const [sendWhatsApp, setSendWhatsApp] = useState(alertSettings.sendWhatsApp);
  const [emailTpl, setEmailTpl] = useState(alertSettings.defaultEmailTemplate);
  const [smsTpl, setSmsTpl] = useState(alertSettings.defaultSMSTemplate);
  const [testSent, setTestSent] = useState(false);

  const handleAddTeacher = () => {
    if (name && subject) {
      onAddTeacher({
        id: `t-${Date.now()}`,
        name,
        subject,
        availability: ['Monday', 'Wednesday', 'Friday']
      });
      setName('');
      setSubject('');
      setIsAddingTeacher(false);
    }
  };

  const handleSaveProfile = () => {
    onUpdateAdmin({
      name: adminName,
      email: adminEmail,
      role: adminRole,
      department: adminDept,
      institution: adminInst,
    });
    setProfileSaved(true);
    setTimeout(() => setProfileSaved(false), 2500);
  };

  const handleSaveNotifications = () => {
    onUpdateAlertSettings({
      ...alertSettings,
      autoSendOnNoClass: autoSendNoClass,
      sendEmail,
      sendSMS,
      sendWhatsApp,
      defaultEmailTemplate: emailTpl,
      defaultSMSTemplate: smsTpl,
      senderName: `Admin ${adminName} (Timetable Office)`,
      senderEmail: adminEmail,
    });
    setProfileSaved(true);
    setTimeout(() => setProfileSaved(false), 2500);
  };

  const handleTriggerTestAlert = () => {
    onSendTestAlert({
      type: 'no_class',
      day: 'Tomorrow (Wednesday)',
      time: '11:00 AM',
      channels: ['email', 'sms', 'whatsapp'],
      recipientsCount: 145,
      title: 'TEST: Automated Free Period Student Dispatch',
      content: `Automated test notification from Admin ${adminName} (${adminEmail}): No class scheduled on Wednesday 11:00 AM. Free study period.`,
      studentGroup: 'All Academic Batches'
    });
    setTestSent(true);
    setTimeout(() => setTestSent(false), 3000);
  };

  return (
    <div className="p-8 max-w-6xl mx-auto">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
        <div>
          <div className="flex items-center gap-3 mb-1">
            <h2 className="text-3xl font-display font-bold">System & Notification Settings</h2>
            <span className="px-3 py-1 rounded-full bg-blue-500/20 text-blue-300 text-xs font-bold border border-blue-500/30">
              Admin: {admin.name}
            </span>
          </div>
          <p className="text-slate-400 text-sm">
            Configure automated student alerts, free period mailings, and administrative privileges.
          </p>
        </div>
        {profileSaved && (
          <div className="px-4 py-2 bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 rounded-xl text-xs font-bold flex items-center gap-2 animate-in fade-in">
            <CheckCircle2 size={16} /> Changes Saved Successfully
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Navigation Tabs */}
        <div className="lg:col-span-1 space-y-2">
          {[
            { id: 'notifications', icon: Bell, label: 'Student Alerts (No-Class)', desc: 'Auto-mail & SMS dispatch' },
            { id: 'profile', icon: Globe, label: 'Admin Navya Profile', desc: 'Identity & email credentials' },
            { id: 'teachers', icon: User, label: 'Teacher Management', desc: 'Faculty directory & schedules' },
            { id: 'constraints', icon: Shield, label: 'Global Constraints', desc: 'Room & overlap policies' },
          ].map((item) => (
            <button 
              key={item.id}
              onClick={() => setActiveTab(item.id as any)}
              className={`w-full flex items-start gap-3.5 p-4 rounded-2xl transition-all text-left ${
                activeTab === item.id 
                  ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/25 border border-blue-400/40' 
                  : 'glass glass-hover text-slate-300'
              }`}
            >
              <div className={`p-2 rounded-xl mt-0.5 ${activeTab === item.id ? 'bg-white/20' : 'bg-white/5'}`}>
                <item.icon size={18} />
              </div>
              <div>
                <span className="font-bold text-sm block">{item.label}</span>
                <span className={`text-[11px] block mt-0.5 ${activeTab === item.id ? 'text-blue-100' : 'text-slate-500'}`}>
                  {item.desc}
                </span>
              </div>
            </button>
          ))}
        </div>

        {/* Content Area */}
        <div className="lg:col-span-2 space-y-8">
          {/* 1. NOTIFICATIONS TAB */}
          {activeTab === 'notifications' && (
            <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
              <section className="glass p-7 rounded-3xl border border-white/10 relative overflow-hidden">
                <div className="flex items-start justify-between mb-6">
                  <div>
                    <h3 className="font-bold text-lg text-white flex items-center gap-2.5">
                      <Mail className="text-blue-400" size={20} /> Automated "No Class" Student Notifications
                    </h3>
                    <p className="text-xs text-slate-400 mt-1">
                      Instantly sends emails and SMS messages to students when a time slot has no class or a faculty member is on leave.
                    </p>
                  </div>
                  <span className="px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-400 text-[11px] font-mono font-bold">
                    SYSTEM ACTIVE
                  </span>
                </div>

                <div className="space-y-4">
                  {/* Master toggle */}
                  <div className="p-4 rounded-2xl bg-blue-600/10 border border-blue-500/30 flex items-center justify-between">
                    <div>
                      <h4 className="font-bold text-sm text-blue-200">Auto-Dispatch on "No Class" (Free Periods)</h4>
                      <p className="text-xs text-slate-400">
                        Automatically trigger email & SMS delivery to students for all free slots in generated timetable.
                      </p>
                    </div>
                    <button 
                      onClick={() => setAutoSendNoClass(!autoSendNoClass)}
                      className={`w-14 h-7 rounded-full relative transition-all duration-300 ${
                        autoSendNoClass ? 'bg-blue-600' : 'bg-slate-700'
                      }`}
                    >
                      <div className={`absolute top-1 w-5 h-5 rounded-full bg-white transition-all duration-300 ${
                        autoSendNoClass ? 'left-8' : 'left-1'
                      }`} />
                    </button>
                  </div>

                  {/* Channel selections */}
                  <div className="grid grid-cols-3 gap-3 pt-2">
                    <label className={`p-3.5 rounded-2xl border flex items-center gap-3 cursor-pointer transition-all ${sendEmail ? 'bg-blue-600/20 border-blue-500/40 text-white' : 'bg-white/5 border-white/10 text-slate-400'}`}>
                      <input 
                        type="checkbox" 
                        checked={sendEmail} 
                        onChange={(e) => setSendEmail(e.target.checked)} 
                        className="accent-blue-500"
                      />
                      <div>
                        <p className="font-bold text-xs">Email Gateway</p>
                        <p className="text-[10px] text-slate-400">Student inboxes</p>
                      </div>
                    </label>

                    <label className={`p-3.5 rounded-2xl border flex items-center gap-3 cursor-pointer transition-all ${sendSMS ? 'bg-cyan-600/20 border-cyan-500/40 text-white' : 'bg-white/5 border-white/10 text-slate-400'}`}>
                      <input 
                        type="checkbox" 
                        checked={sendSMS} 
                        onChange={(e) => setSendSMS(e.target.checked)} 
                        className="accent-cyan-500"
                      />
                      <div>
                        <p className="font-bold text-xs">SMS Broadcast</p>
                        <p className="text-[10px] text-slate-400">Mobile SMS alerts</p>
                      </div>
                    </label>

                    <label className={`p-3.5 rounded-2xl border flex items-center gap-3 cursor-pointer transition-all ${sendWhatsApp ? 'bg-emerald-600/20 border-emerald-500/40 text-white' : 'bg-white/5 border-white/10 text-slate-400'}`}>
                      <input 
                        type="checkbox" 
                        checked={sendWhatsApp} 
                        onChange={(e) => setSendWhatsApp(e.target.checked)} 
                        className="accent-emerald-500"
                      />
                      <div>
                        <p className="font-bold text-xs">WhatsApp API</p>
                        <p className="text-[10px] text-slate-400">Class group chats</p>
                      </div>
                    </label>
                  </div>

                  {/* Sender identity config */}
                  <div className="pt-3">
                    <label className="block text-xs font-bold text-slate-300 mb-1.5">Official Sender Display Name & Email</label>
                    <div className="grid grid-cols-2 gap-3">
                      <input 
                        type="text" 
                        value={`Admin ${admin.name} (Timetable Operations)`}
                        disabled
                        className="bg-white/5 border border-white/10 rounded-xl px-4 py-2 text-xs text-slate-300"
                      />
                      <input 
                        type="text" 
                        value={admin.email}
                        disabled
                        className="bg-white/5 border border-white/10 rounded-xl px-4 py-2 text-xs text-blue-300 font-mono"
                      />
                    </div>
                  </div>

                  {/* Email template */}
                  <div className="pt-2">
                    <label className="block text-xs font-bold text-slate-300 mb-1.5">Default Student Email Message Template</label>
                    <textarea 
                      rows={3}
                      value={emailTpl}
                      onChange={(e) => setEmailTpl(e.target.value)}
                      className="w-full bg-white/5 border border-white/10 rounded-2xl p-4 text-xs text-slate-200 outline-none focus:border-blue-500/60 font-mono leading-relaxed"
                    />
                    <p className="text-[10px] text-slate-500 mt-1">Available variables: {"{DAY}"}, {"{TIME}"}, {"{REASON}"}, {"{STUDENT_NAME}"}</p>
                  </div>

                  {/* SMS template */}
                  <div>
                    <label className="block text-xs font-bold text-slate-300 mb-1.5">Default SMS Alert Template</label>
                    <input 
                      type="text"
                      value={smsTpl}
                      onChange={(e) => setSmsTpl(e.target.value)}
                      className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 text-xs text-slate-200 outline-none focus:border-blue-500/60 font-mono"
                    />
                  </div>

                  {/* Buttons */}
                  <div className="flex items-center justify-between pt-4 border-t border-white/10">
                    <button 
                      onClick={handleTriggerTestAlert}
                      className="px-4 py-2.5 bg-white/5 hover:bg-white/10 border border-white/10 rounded-xl text-xs font-bold flex items-center gap-2 text-slate-200 transition-all"
                    >
                      <Send size={14} className="text-blue-400" />
                      {testSent ? '✓ Test Alert Sent to Students!' : 'Send Test Notification to Students'}
                    </button>

                    <button 
                      onClick={handleSaveNotifications}
                      className="px-6 py-2.5 bg-blue-600 hover:bg-blue-500 rounded-xl text-xs font-bold flex items-center gap-2 transition-all shadow-lg shadow-blue-600/20 text-white"
                    >
                      <Save size={14} /> Save Notification Settings
                    </button>
                  </div>
                </div>
              </section>

              {/* Recent Dispatches Log */}
              <section className="glass p-6 rounded-3xl border border-white/10">
                <h4 className="font-bold text-sm text-white mb-4 flex items-center gap-2">
                  <MessageSquare size={16} className="text-blue-400" /> Automated Dispatch Log ({alerts.length} Records)
                </h4>
                <div className="space-y-2 max-h-48 overflow-y-auto">
                  {alerts.map((al) => (
                    <div key={al.id} className="p-3 bg-white/5 rounded-xl border border-white/5 flex items-center justify-between text-xs">
                      <div>
                        <span className="font-bold text-slate-200 block">{al.title}</span>
                        <span className="text-[10px] text-slate-400">{al.content.slice(0, 75)}...</span>
                      </div>
                      <div className="text-right shrink-0">
                        <span className="text-[10px] text-emerald-400 font-bold flex items-center gap-1 justify-end">
                          <CheckCircle2 size={10} /> {al.recipientsCount} Notified
                        </span>
                        <span className="text-[9px] text-slate-500">{al.sentAt}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </section>
            </motion.div>
          )}

          {/* 2. ADMIN PROFILE TAB */}
          {activeTab === 'profile' && (
            <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="glass p-8 rounded-3xl border border-white/10 space-y-6">
              <div className="flex items-center gap-4 pb-6 border-b border-white/10">
                <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-blue-600 to-cyan-500 flex items-center justify-center text-white font-bold text-2xl shadow-xl shadow-blue-500/20">
                  {adminName.slice(0, 2).toUpperCase()}
                </div>
                <div>
                  <h3 className="text-xl font-bold text-white flex items-center gap-2">
                    {adminName} <span className="px-2.5 py-0.5 rounded-full bg-blue-500/20 text-blue-400 text-xs font-semibold">Master Administrator</span>
                  </h3>
                  <p className="text-xs text-slate-400">{adminEmail}</p>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">Admin User Full Name</label>
                  <input 
                    type="text" 
                    value={adminName}
                    onChange={(e) => setAdminName(e.target.value)}
                    className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 text-sm text-slate-100 outline-none focus:border-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">Official Administrator Email</label>
                  <input 
                    type="email" 
                    value={adminEmail}
                    onChange={(e) => setAdminEmail(e.target.value)}
                    className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 text-sm text-blue-300 font-mono outline-none focus:border-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">Administrative Role / Designation</label>
                  <input 
                    type="text" 
                    value={adminRole}
                    onChange={(e) => setAdminRole(e.target.value)}
                    className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 text-sm text-slate-100 outline-none focus:border-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">Academic Department</label>
                  <input 
                    type="text" 
                    value={adminDept}
                    onChange={(e) => setAdminDept(e.target.value)}
                    className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 text-sm text-slate-100 outline-none focus:border-blue-500"
                  />
                </div>

                <div className="md:col-span-2">
                  <label className="block text-xs font-bold text-slate-300 mb-1">Institutional Organization</label>
                  <input 
                    type="text" 
                    value={adminInst}
                    onChange={(e) => setAdminInst(e.target.value)}
                    className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 text-sm text-slate-100 outline-none focus:border-blue-500"
                  />
                </div>
              </div>

              <div className="pt-4 border-t border-white/10 flex items-center justify-end">
                <button 
                  onClick={handleSaveProfile}
                  className="px-8 py-3 bg-blue-600 hover:bg-blue-500 rounded-xl text-sm font-bold flex items-center gap-2 transition-all shadow-lg shadow-blue-600/20 text-white"
                >
                  <Save size={16} /> Save Admin Profile
                </button>
              </div>
            </motion.div>
          )}

          {/* 3. TEACHER MANAGEMENT TAB */}
          {activeTab === 'teachers' && (
            <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
              <section className="glass rounded-3xl overflow-hidden border border-white/10">
                <div className="p-6 border-b border-white/10 flex items-center justify-between">
                  <h3 className="font-bold flex items-center gap-2 text-white">
                    <User size={18} className="text-blue-400" /> Faculty & Teacher Directory
                  </h3>
                  <button 
                    onClick={() => setIsAddingTeacher(!isAddingTeacher)}
                    className="px-4 py-1.5 bg-blue-600/20 hover:bg-blue-600 text-blue-300 hover:text-white rounded-xl text-xs font-bold transition-all border border-blue-500/30"
                  >
                    {isAddingTeacher ? 'Cancel' : '+ Add Faculty Member'}
                  </button>
                </div>

                {isAddingTeacher && (
                  <motion.div 
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    className="p-6 bg-blue-600/10 border-b border-white/10 space-y-3"
                  >
                    <div className="flex flex-wrap gap-4">
                      <input 
                        type="text" 
                        placeholder="Faculty Name (e.g. Dr. Alan Turing)" 
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        className="flex-1 min-w-[200px] bg-white/5 border border-white/10 rounded-xl px-4 py-2 outline-none focus:border-blue-500 text-sm text-white"
                      />
                      <input 
                        type="text" 
                        placeholder="Subject (e.g. Library & Research, Mathematics)" 
                        value={subject}
                        onChange={(e) => setSubject(e.target.value)}
                        className="flex-1 min-w-[200px] bg-white/5 border border-white/10 rounded-xl px-4 py-2 outline-none focus:border-blue-500 text-sm text-white"
                      />
                      <button 
                        onClick={handleAddTeacher}
                        className="px-6 py-2 bg-blue-600 rounded-xl text-sm font-bold hover:bg-blue-500 transition-all text-white shrink-0"
                      >
                        Save Faculty
                      </button>
                    </div>
                    <div className="flex flex-wrap gap-2 items-center text-xs">
                      <span className="text-slate-400 font-semibold">Quick subject:</span>
                      {['Library & Research', 'Mathematics', 'Physics & Electronics', 'Computer Science & AI'].map(s => (
                        <button
                          key={s}
                          type="button"
                          onClick={() => setSubject(s)}
                          className="px-2 py-0.5 rounded bg-white/5 hover:bg-blue-500/20 text-slate-300 text-[11px] border border-white/10"
                        >
                          + {s}
                        </button>
                      ))}
                    </div>
                  </motion.div>
                )}

                <div className="overflow-x-auto">
                  <table className="w-full text-left">
                    <thead>
                      <tr className="text-[10px] font-bold text-slate-400 uppercase tracking-widest bg-white/5">
                        <th className="px-6 py-4">Name</th>
                        <th className="px-6 py-4">Subject</th>
                        <th className="px-6 py-4">Availability</th>
                        <th className="px-6 py-4 text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-white/5">
                      {teachers.map((teacher) => (
                        <tr key={teacher.id} className="group hover:bg-white/5 transition-colors">
                          <td className="px-6 py-4">
                            <span className="text-sm font-bold text-slate-200">{teacher.name}</span>
                          </td>
                          <td className="px-6 py-4">
                            <span className="text-xs text-slate-400">{teacher.subject}</span>
                          </td>
                          <td className="px-6 py-4">
                            <div className="flex gap-1">
                              {teacher.availability.slice(0, 2).map(day => (
                                <span key={day} className="text-[10px] px-2 py-0.5 bg-blue-500/10 text-blue-400 rounded-full">
                                  {day.slice(0, 3)}
                                </span>
                              ))}
                              {teacher.availability.length > 2 && (
                                <span className="text-[10px] px-2 py-0.5 bg-slate-500/10 text-slate-400 rounded-full">
                                  +{teacher.availability.length - 2}
                                </span>
                              )}
                            </div>
                          </td>
                          <td className="px-6 py-4 text-right">
                            <div className="flex items-center justify-end gap-2">
                              <button 
                                onClick={() => onRemoveTeacher(teacher.id)}
                                className="p-2 hover:bg-red-600/20 text-red-400 rounded-lg transition-all"
                                title="Remove faculty"
                              >
                                <Trash2 size={14} />
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </section>
            </motion.div>
          )}

          {/* 4. GLOBAL CONSTRAINTS TAB */}
          {activeTab === 'constraints' && (
            <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="glass p-8 rounded-3xl border border-white/10 space-y-6">
              <h3 className="font-bold flex items-center gap-2 text-white text-lg">
                <Shield size={20} className="text-blue-400" /> Academic & Room Constraints
              </h3>
              <div className="space-y-5">
                {[
                  { label: 'Mandatory 12:45 PM - 01:30 PM Lunch & Recess Break', desc: 'Guarantees 12:45 PM to 01:30 PM is 100% reserved for lunch & dining. Zero classes scheduled across all batches.', active: true, badge: 'Enforced' },
                  { label: 'No overlapping classes for faculty & rooms', desc: 'Prevent teachers and classrooms from being double-booked.', active: true },
                  { label: 'Max 1 continuous lecture hour per subject', desc: 'Prevents student fatigue by staggering lecture hours with diverse subjects.', active: true },
                  { label: 'Notify students on empty slots & free periods', desc: 'Automatically dispatch Email and SMS notifications when slots are unassigned.', active: true },
                  { label: 'Room capacity & laboratory equipment check', desc: 'Validate student count against classroom seating and lab workbench availability.', active: true }
                ].map((toggle, i) => (
                  <div key={i} className="flex items-center justify-between p-4 bg-white/5 rounded-2xl border border-white/5">
                    <div>
                      <div className="flex items-center gap-2">
                        <h4 className="text-sm font-bold text-slate-200">{toggle.label}</h4>
                        {toggle.badge && (
                          <span className="px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 text-[10px] font-bold border border-amber-500/30">
                            {toggle.badge}
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-slate-400 mt-0.5">{toggle.desc}</p>
                    </div>
                    <div className="w-12 h-6 rounded-full relative bg-blue-600 cursor-pointer shrink-0">
                      <div className="absolute top-1 w-4 h-4 rounded-full bg-white left-7" />
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>
          )}
        </div>
      </div>
    </div>
  );
}
