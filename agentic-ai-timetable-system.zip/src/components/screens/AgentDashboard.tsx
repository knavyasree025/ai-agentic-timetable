import React, { useState, FormEvent } from 'react';
import { motion } from 'motion/react';
import { Bot, ShieldAlert, Zap, Send, Terminal, Activity, CheckCircle2, Loader2, Bell, Mail, MessageSquare } from 'lucide-react';
import { MOCK_AGENTS } from '../../constants';
import { AdminProfile } from '../../types';

interface AgentDashboardProps {
  isGenerating: boolean;
  onComplete: () => void;
  admin?: AdminProfile;
}

export default function AgentDashboard({ isGenerating, onComplete, admin }: AgentDashboardProps) {
  const [agentMessages, setAgentMessages] = useState<Array<{ sender: string; text: string; color: string }>>([
    { sender: 'Scheduler', text: "Mandatory Lunch & Recess Break (12:45 PM - 01:30 PM) locked across all faculty and student batches.", color: 'bg-blue-600' },
    { sender: 'Conflict Resolver', text: "Verified: 0 lectures scheduled between 12:45 PM and 01:30 PM. Room constraints synchronized.", color: 'bg-red-600' },
    { sender: 'Notification Agent', text: `Auto-alert rule enabled by Admin ${admin?.name || 'Navya'}: Student Email & SMS dispatched for all free academic periods.`, color: 'bg-amber-600' }
  ]);
  const [userInput, setUserInput] = useState('');

  const handleSendMessage = (e: FormEvent) => {
    e.preventDefault();
    if (!userInput.trim()) return;
    const newMsg = { sender: `Admin ${admin?.name || 'Navya'}`, text: userInput, color: 'bg-indigo-600' };
    setAgentMessages(prev => [...prev, newMsg]);
    setUserInput('');

    setTimeout(() => {
      setAgentMessages(prev => [
        ...prev,
        {
          sender: 'Notification Agent',
          text: `Acknowledged instruction from Admin ${admin?.name || 'Navya'}. Constraints synchronized and student alerts verified.`,
          color: 'bg-amber-600'
        }
      ]);
    }, 900);
  };

  return (
    <div className="p-8 max-w-7xl mx-auto">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-10">
        <div>
          <div className="flex items-center gap-3 mb-2">
            <h2 className="text-3xl font-display font-bold">Multi-Agent Orchestration Hub</h2>
            <span className="px-3 py-1 rounded-full bg-blue-500/20 text-blue-300 text-xs font-bold border border-blue-500/30">
              Admin: {admin?.name || 'Navya'}
            </span>
          </div>
          <p className="text-slate-400 text-sm">Real-time collaboration across scheduling, conflict validation, and student alert dispatching.</p>
        </div>
        <div className="flex items-center gap-4">
          <div className="px-4 py-2 glass rounded-xl flex items-center gap-2">
            <Activity size={16} className={isGenerating ? 'text-blue-400 animate-pulse' : 'text-emerald-400'} />
            <span className="text-sm font-medium">System Load: {isGenerating ? '88%' : '12%'}</span>
          </div>
          <button 
            disabled={isGenerating}
            onClick={onComplete}
            className={`px-6 py-2.5 rounded-xl text-sm font-bold transition-all shadow-lg ${
              isGenerating 
                ? 'bg-slate-700 text-slate-400 cursor-not-allowed' 
                : 'bg-emerald-600 text-white hover:bg-emerald-500 shadow-emerald-600/20'
            }`}
          >
            {isGenerating ? 'Agents Processing...' : 'View Generated Timetable'}
          </button>
        </div>
      </div>

      {/* 4 Agent Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
        {MOCK_AGENTS.map((agent, i) => (
          <motion.div
            key={agent.id}
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: i * 0.08 }}
            className="glass p-6 rounded-3xl relative overflow-hidden group flex flex-col justify-between"
          >
            {/* Background Glow */}
            <div className={`absolute -top-10 -right-10 w-32 h-32 blur-[60px] opacity-20 transition-all group-hover:opacity-40 ${
              agent.status === 'working' ? 'bg-blue-500' : agent.status === 'completed' ? 'bg-emerald-500' : 'bg-slate-500'
            }`} />

            <div>
              <div className="flex items-start justify-between mb-5">
                <div className={`w-12 h-12 rounded-2xl flex items-center justify-center shadow-lg ${
                  agent.icon === 'Bell' ? 'bg-amber-600 text-white' :
                  agent.status === 'working' ? 'bg-blue-600 text-white' : 
                  agent.status === 'completed' ? 'bg-emerald-600 text-white' : 'bg-slate-700 text-white'
                }`}>
                  {agent.icon === 'Bot' && <Bot size={24} />}
                  {agent.icon === 'ShieldAlert' && <ShieldAlert size={24} />}
                  {agent.icon === 'Zap' && <Zap size={24} />}
                  {agent.icon === 'Bell' && <Bell size={24} />}
                </div>
                <div className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider border ${
                  agent.status === 'working' ? 'bg-blue-500/10 text-blue-400 border-blue-500/20' : 
                  agent.status === 'completed' ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20' : 
                  'bg-slate-500/10 text-slate-400 border-slate-500/20'
                }`}>
                  {agent.status}
                </div>
              </div>

              <h3 className="text-base font-bold text-white mb-0.5">{agent.name}</h3>
              <p className="text-slate-400 text-xs mb-4">{agent.role}</p>

              <div className="space-y-2 mb-6">
                <div className="flex items-center justify-between text-[10px] font-semibold text-slate-500 uppercase tracking-widest">
                  <span>Live Activity Logs</span>
                  <Terminal size={11} />
                </div>
                <div className="bg-black/30 rounded-xl p-3 font-mono text-[10px] space-y-1.5 h-28 overflow-y-auto border border-white/5">
                  {agent.logs.map((log, j) => (
                    <div key={j} className="flex gap-1.5 leading-tight">
                      <span className="text-blue-500/60 font-sans">&gt;</span>
                      <span className="text-slate-300">{log}</span>
                    </div>
                  ))}
                  {agent.status === 'working' && (
                    <div className="flex items-center gap-1.5 text-blue-400 pt-1">
                      <Loader2 size={10} className="animate-spin" />
                      <span>Syncing...</span>
                    </div>
                  )}
                </div>
              </div>
            </div>

            <div className="w-full bg-white/5 h-1.5 rounded-full overflow-hidden">
              <motion.div 
                initial={{ width: 0 }}
                animate={{ width: agent.status === 'completed' ? '100%' : agent.status === 'working' ? '70%' : '10%' }}
                className={`h-full ${agent.status === 'completed' ? 'bg-emerald-500' : 'bg-blue-500'}`}
              />
            </div>
          </motion.div>
        ))}
      </div>

      {/* Summary Panels & Agent Chat */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="glass p-6 rounded-3xl border-l-4 border-l-amber-500">
              <div className="flex items-center gap-4 mb-3">
                <div className="w-10 h-10 rounded-xl bg-amber-500/10 flex items-center justify-center text-amber-400">
                  <Mail size={20} />
                </div>
                <div>
                  <h4 className="font-bold text-white">Student Auto-Alert Status</h4>
                  <p className="text-xs text-slate-400">Managed by Admin {admin?.name || 'Navya'}</p>
                </div>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed">
                Notification Agent is synced to detect empty periods and dispatch instant Email & SMS messages to all enrolled batches.
              </p>
            </div>

            <div className="glass p-6 rounded-3xl border-l-4 border-l-emerald-500">
              <div className="flex items-center gap-4 mb-3">
                <div className="w-10 h-10 rounded-xl bg-emerald-500/10 flex items-center justify-center text-emerald-400">
                  <CheckCircle2 size={20} />
                </div>
                <div>
                  <h4 className="font-bold text-white">Constraint Satisfaction</h4>
                  <p className="text-xs text-slate-400">Zero unhandled clashes</p>
                </div>
              </div>
              <div className="flex items-end gap-2">
                <span className="text-3xl font-display font-bold text-emerald-400">99.4%</span>
                <span className="text-xs text-slate-400 mb-1">matrix efficiency rating</span>
              </div>
            </div>
          </div>

          {/* Real-time Agent Communication Channel */}
          <div className="glass p-6 rounded-3xl flex flex-col">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-3">
                <Bot className="text-blue-400" size={20} />
                <h4 className="font-bold text-white text-sm">Agent Inter-Communication & Command Feed</h4>
              </div>
              <span className="text-[10px] px-2.5 py-0.5 rounded-full bg-blue-500/10 text-blue-400 border border-blue-500/20 font-mono">
                LIVE
              </span>
            </div>
            
            <div className="bg-black/30 rounded-2xl p-4 mb-4 overflow-y-auto text-xs space-y-3 max-h-56 min-h-[140px] border border-white/5">
              {agentMessages.map((msg, idx) => (
                <div key={idx} className="flex gap-2.5">
                  <div className={`w-7 h-7 rounded-lg ${msg.color} flex-shrink-0 flex items-center justify-center text-white font-bold text-[10px]`}>
                    {msg.sender.slice(0, 1)}
                  </div>
                  <div className="bg-white/5 p-2.5 rounded-2xl rounded-tl-none border border-white/5 flex-1">
                    <span className="text-[10px] font-bold text-slate-300 block mb-0.5">{msg.sender}</span>
                    <p className="text-slate-200 text-xs">{msg.text}</p>
                  </div>
                </div>
              ))}
            </div>

            <form onSubmit={handleSendMessage} className="relative">
              <input 
                type="text" 
                value={userInput}
                onChange={(e) => setUserInput(e.target.value)}
                placeholder={`Instruct agents as Admin ${admin?.name || 'Navya'} (e.g. "Notify Batch A of afternoon free period")...`} 
                className="w-full bg-white/5 border border-white/10 rounded-2xl py-3 px-5 pr-12 outline-none focus:border-blue-500 text-xs text-white placeholder:text-slate-500"
              />
              <button 
                type="submit"
                className="absolute right-2 top-1/2 -translate-y-1/2 p-2 bg-blue-600 hover:bg-blue-500 text-white rounded-xl transition-all"
              >
                <Send size={15} />
              </button>
            </form>
          </div>
        </div>

        {/* System Health */}
        <div className="glass p-7 rounded-3xl flex flex-col justify-between">
          <div>
            <h4 className="font-bold text-white mb-6">System Health & Gateways</h4>
            <div className="space-y-5">
              {[
                { label: 'Neural Scheduler Core', value: 96 },
                { label: 'Constraint Validator Engine', value: 89 },
                { label: 'Student Mail Gateway (SMTP)', value: 100 },
                { label: 'SMS / WhatsApp Dispatcher', value: 98 }
              ].map((metric, i) => (
                <div key={i}>
                  <div className="flex justify-between text-xs font-semibold mb-1.5">
                    <span className="text-slate-400">{metric.label}</span>
                    <span className={metric.value > 90 ? 'text-emerald-400' : 'text-blue-400'}>{metric.value}%</span>
                  </div>
                  <div className="h-1.5 bg-white/5 rounded-full overflow-hidden">
                    <div className="h-full bg-gradient-to-r from-blue-600 to-cyan-500 rounded-full" style={{ width: `${metric.value}%` }} />
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="mt-8 p-4 rounded-2xl bg-blue-600/10 border border-blue-500/20">
            <h5 className="text-xs font-bold text-blue-300 mb-1 flex items-center gap-1.5">
              <Mail size={14} /> Student Notification Assurance
            </h5>
            <p className="text-[11px] text-slate-300 leading-relaxed">
              Every empty timetable period triggers a simulated delivery to all registered student devices authenticated under Admin {admin?.name || 'Navya'}.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
