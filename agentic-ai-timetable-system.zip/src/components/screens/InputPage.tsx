import { useState, FormEvent } from 'react';
import { motion } from 'motion/react';
import { 
  Plus, 
  Trash2, 
  Users, 
  BookOpen, 
  MapPin, 
  Clock, 
  CheckCircle2, 
  Sparkles,
  Library,
  GraduationCap,
  CalendarCheck,
  Check
} from 'lucide-react';

import { Teacher } from '../../types';

interface InputPageProps {
  subjects: string[];
  onAddSubject: (subject: string) => void;
  onRemoveSubject: (subject: string) => void;
  teachers: Teacher[];
  onAddTeacher: (teacher: Teacher) => void;
  onRemoveTeacher: (id: string) => void;
  classrooms: string[];
  onAddClassroom: (room: string) => void;
  onRemoveClassroom: (room: string) => void;
  onGenerate: () => void;
}

const ALL_DAYS = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];

export default function InputPage({ 
  subjects, onAddSubject, onRemoveSubject, 
  teachers, onAddTeacher, onRemoveTeacher,
  classrooms, onAddClassroom, onRemoveClassroom,
  onGenerate 
}: InputPageProps) {
  // Subjects state
  const [newSubject, setNewSubject] = useState('');

  // Teacher input state
  const [teacherName, setTeacherName] = useState('');
  const [selectedSubject, setSelectedSubject] = useState('');
  const [customSubject, setCustomSubject] = useState('');
  const [selectedDays, setSelectedDays] = useState<string[]>([...ALL_DAYS]);
  const [inputError, setInputError] = useState('');

  // Classroom state
  const [newClassroom, setNewClassroom] = useState('');

  const handleAddSubjectLocal = (subName?: string) => {
    const target = (subName || newSubject).trim();
    if (target) {
      onAddSubject(target);
      if (!subName) setNewSubject('');
      if (!selectedSubject) setSelectedSubject(target);
    }
  };

  const handleAddTeacherLocal = (e?: FormEvent) => {
    if (e) e.preventDefault();
    setInputError('');

    const trimmedName = teacherName.trim();
    const finalSubject = (selectedSubject === '__custom__' ? customSubject : selectedSubject).trim();

    if (!trimmedName) {
      setInputError('Please enter a teacher name.');
      return;
    }

    if (!finalSubject) {
      setInputError('Please select or enter an assigned subject.');
      return;
    }

    // Ensure subject is in subjects list
    if (!subjects.includes(finalSubject)) {
      onAddSubject(finalSubject);
    }

    onAddTeacher({
      id: `teacher-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
      name: trimmedName,
      subject: finalSubject,
      availability: selectedDays.length > 0 ? selectedDays : [...ALL_DAYS]
    });

    // Reset teacher form fields
    setTeacherName('');
    setCustomSubject('');
    setSelectedDays([...ALL_DAYS]);
  };

  const toggleDay = (day: string) => {
    setSelectedDays(prev => 
      prev.includes(day) 
        ? prev.filter(d => d !== day) 
        : [...prev, day]
    );
  };

  const handleAddClassroomLocal = (roomName?: string) => {
    const target = (roomName || newClassroom).trim();
    if (target) {
      onAddClassroom(target);
      if (!roomName) setNewClassroom('');
    }
  };

  const loadStandardLibraryPreset = () => {
    if (!subjects.includes('Library & Research')) onAddSubject('Library & Research');
    if (!classrooms.includes('Central Library Hall')) onAddClassroom('Central Library Hall');
    if (!teachers.some(t => t.name === 'Mrs. Clara Evans')) {
      onAddTeacher({
        id: `t-lib-${Date.now()}`,
        name: 'Mrs. Clara Evans',
        subject: 'Library & Research',
        availability: [...ALL_DAYS]
      });
    }
  };

  return (
    <div className="p-6 sm:p-8 max-w-6xl mx-auto space-y-8">
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-6 rounded-3xl bg-gradient-to-r from-blue-900/30 via-indigo-900/20 to-purple-900/30 border border-white/10">
        <div>
          <div className="flex items-center gap-2.5 mb-1.5">
            <GraduationCap className="text-blue-400" size={26} />
            <h2 className="text-2xl sm:text-3xl font-display font-bold text-white">Academic Curriculum Configuration</h2>
          </div>
          <p className="text-slate-300 text-sm">
            Arrange faculty, departmental subjects, Central Library slots, and scheduling constraints.
          </p>
        </div>
        <button
          onClick={loadStandardLibraryPreset}
          className="px-4 py-2.5 rounded-2xl bg-amber-500/20 hover:bg-amber-500/30 border border-amber-500/40 text-amber-200 text-xs font-bold transition-all flex items-center gap-2 self-start sm:self-auto shrink-0 shadow-lg shadow-amber-500/10"
        >
          <Library size={16} className="text-amber-400" />
          Quick Add Library & Staff
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Left Column: Subjects & Teachers */}
        <div className="space-y-8">
          {/* Subjects Card */}
          <section className="glass p-6 sm:p-7 rounded-3xl border border-white/10 shadow-xl">
            <div className="flex items-center justify-between mb-5">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-blue-500/20 text-blue-400 flex items-center justify-center border border-blue-500/30">
                  <BookOpen size={20} />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-white">Academic Subjects</h3>
                  <p className="text-xs text-slate-400">{subjects.length} subjects registered</p>
                </div>
              </div>
            </div>
            
            {/* Quick Add Suggested Subjects */}
            <div className="mb-4 flex flex-wrap gap-2 items-center">
              <span className="text-[11px] font-semibold text-slate-400 flex items-center gap-1">
                <Sparkles size={12} className="text-blue-400" /> Suggested:
              </span>
              {['Library & Research', 'Mathematics', 'Physics & Electronics', 'AI & Machine Learning', 'Chemistry'].map(s => (
                <button
                  key={s}
                  onClick={() => handleAddSubjectLocal(s)}
                  disabled={subjects.includes(s)}
                  className={`text-[10px] px-2.5 py-1 rounded-lg border font-medium transition-all ${
                    subjects.includes(s)
                      ? 'bg-emerald-500/10 text-emerald-300 border-emerald-500/30 cursor-default opacity-60'
                      : 'bg-white/5 hover:bg-blue-600/20 text-slate-300 hover:text-white border-white/10 hover:border-blue-500/40'
                  }`}
                >
                  {subjects.includes(s) ? '✓ ' : '+ '}{s}
                </button>
              ))}
            </div>

            <div className="flex gap-2 mb-4">
              <input 
                type="text" 
                value={newSubject}
                onChange={(e) => setNewSubject(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleAddSubjectLocal()}
                placeholder="Type subject name (e.g. Data Structures)..."
                className="flex-1 bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 outline-none focus:border-blue-500/50 transition-all text-sm placeholder:text-slate-500 text-white"
              />
              <button 
                onClick={() => handleAddSubjectLocal()}
                className="px-4 py-2.5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl font-bold text-xs transition-all flex items-center gap-1.5 shrink-0 shadow-lg shadow-blue-600/20"
              >
                <Plus size={16} /> Add
              </button>
            </div>

            <div className="space-y-2 max-h-56 overflow-y-auto pr-1 custom-scrollbar">
              {subjects.map((sub) => {
                const assignedTeacher = teachers.find(t => t.subject.toLowerCase() === sub.toLowerCase());
                const isLibrary = sub.toLowerCase().includes('library');
                return (
                  <motion.div 
                    initial={{ opacity: 0, y: 5 }}
                    animate={{ opacity: 1, y: 0 }}
                    key={sub} 
                    className="flex items-center justify-between p-3.5 bg-white/[0.04] hover:bg-white/[0.07] rounded-2xl border border-white/5 group transition-all"
                  >
                    <div className="flex items-center gap-2.5">
                      <div className={`w-2.5 h-2.5 rounded-full ${isLibrary ? 'bg-amber-400' : 'bg-blue-400'}`} />
                      <span className="font-semibold text-sm text-slate-100">{sub}</span>
                      {isLibrary && (
                        <span className="px-2 py-0.5 rounded-md bg-amber-500/20 text-amber-300 text-[10px] font-bold border border-amber-500/30">
                          Library Period
                        </span>
                      )}
                    </div>
                    
                    <div className="flex items-center gap-3">
                      {assignedTeacher ? (
                        <span className="text-[11px] text-slate-400 hidden sm:inline-block">
                          {assignedTeacher.name}
                        </span>
                      ) : (
                        <span className="text-[10px] text-amber-400/80 font-mono hidden sm:inline-block">
                          No faculty assigned
                        </span>
                      )}
                      <button 
                        onClick={() => onRemoveSubject(sub)}
                        className="text-slate-500 hover:text-red-400 p-1 rounded-lg hover:bg-red-500/10 transition-all opacity-70 group-hover:opacity-100"
                        title="Remove Subject"
                      >
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </motion.div>
                );
              })}
            </div>
          </section>

          {/* Teacher & Faculty Section */}
          <section className="glass p-6 sm:p-7 rounded-3xl border border-white/10 shadow-xl">
            <div className="flex items-center justify-between mb-5">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-purple-500/20 text-purple-400 flex items-center justify-center border border-purple-500/30">
                  <Users size={20} />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-white">Faculty & Teacher Assignment</h3>
                  <p className="text-xs text-slate-400">{teachers.length} faculty members active</p>
                </div>
              </div>
            </div>
            
            {/* Structured Neat Teacher Input Box */}
            <form onSubmit={handleAddTeacherLocal} className="p-4 rounded-2xl bg-white/[0.03] border border-white/10 space-y-3 mb-5">
              <div className="text-xs font-bold text-slate-300 uppercase tracking-wider mb-1 flex items-center gap-1.5">
                <Plus size={14} className="text-blue-400" /> Add Faculty Member
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {/* Teacher Name Input */}
                <div>
                  <label className="block text-[11px] font-semibold text-slate-400 mb-1">
                    Teacher Name
                  </label>
                  <input 
                    type="text" 
                    value={teacherName}
                    onChange={(e) => setTeacherName(e.target.value)}
                    placeholder="e.g. Dr. Alan Turing"
                    className="w-full bg-white/5 border border-white/10 rounded-xl px-3.5 py-2 outline-none focus:border-purple-500/50 transition-all text-sm text-white placeholder:text-slate-500"
                  />
                </div>

                {/* Assigned Subject Select Dropdown */}
                <div>
                  <label className="block text-[11px] font-semibold text-slate-400 mb-1">
                    Assigned Subject
                  </label>
                  <select
                    value={selectedSubject}
                    onChange={(e) => setSelectedSubject(e.target.value)}
                    className="w-full bg-slate-900 border border-white/10 rounded-xl px-3.5 py-2 outline-none focus:border-purple-500/50 transition-all text-sm text-white cursor-pointer"
                  >
                    <option value="" disabled>-- Select Subject --</option>
                    {subjects.map(s => (
                      <option key={s} value={s}>{s}</option>
                    ))}
                    <option value="__custom__">+ Enter custom subject...</option>
                  </select>
                </div>
              </div>

              {/* If custom subject chosen */}
              {selectedSubject === '__custom__' && (
                <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }}>
                  <input 
                    type="text"
                    value={customSubject}
                    onChange={(e) => setCustomSubject(e.target.value)}
                    placeholder="Type new subject title..."
                    className="w-full bg-white/5 border border-purple-500/30 rounded-xl px-3.5 py-2 outline-none focus:border-purple-500 text-sm text-white placeholder:text-slate-500"
                  />
                </motion.div>
              )}

              {/* Availability Days Selector */}
              <div>
                <label className="block text-[11px] font-semibold text-slate-400 mb-1.5 flex items-center justify-between">
                  <span>Weekly Availability Days:</span>
                  <span className="text-[10px] text-purple-300">{selectedDays.length} of 5 days active</span>
                </label>
                <div className="flex flex-wrap gap-1.5">
                  {ALL_DAYS.map(day => {
                    const isActive = selectedDays.includes(day);
                    return (
                      <button
                        type="button"
                        key={day}
                        onClick={() => toggleDay(day)}
                        className={`px-2.5 py-1 rounded-lg text-xs font-semibold border transition-all ${
                          isActive 
                            ? 'bg-purple-600/30 text-purple-200 border-purple-500/50 shadow-sm' 
                            : 'bg-white/5 text-slate-500 border-white/5 hover:text-slate-300'
                        }`}
                      >
                        {day.slice(0, 3)}
                      </button>
                    );
                  })}
                </div>
              </div>

              {inputError && (
                <p className="text-xs text-rose-400 font-medium">{inputError}</p>
              )}

              <button 
                type="submit"
                className="w-full py-2.5 bg-purple-600 hover:bg-purple-500 text-white rounded-xl font-bold text-xs transition-all flex items-center justify-center gap-1.5 shadow-lg shadow-purple-600/20"
              >
                <Check size={16} /> Save Faculty & Assign Subject
              </button>
            </form>

            {/* List of Teachers */}
            <div className="space-y-3 max-h-64 overflow-y-auto pr-1 custom-scrollbar">
              {teachers.map((teacher) => (
                <div key={teacher.id} className="p-3.5 bg-white/[0.03] hover:bg-white/[0.06] rounded-2xl border border-white/5 group hover:border-white/10 transition-all">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-sm text-slate-100">{teacher.name}</span>
                      <span className="px-2.5 py-0.5 rounded-full bg-purple-500/20 text-purple-300 text-[11px] font-medium border border-purple-500/30">
                        {teacher.subject}
                      </span>
                    </div>
                    <button 
                      onClick={() => onRemoveTeacher(teacher.id)}
                      className="text-slate-500 hover:text-red-400 p-1 rounded-lg hover:bg-red-500/10 transition-all opacity-70 group-hover:opacity-100"
                      title="Remove Faculty"
                    >
                      <Trash2 size={16} />
                    </button>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <CalendarCheck size={12} className="text-slate-400" />
                    <span className="text-[10px] text-slate-400 mr-1">Available:</span>
                    {teacher.availability.map(day => (
                      <span key={day} className="text-[9px] px-2 py-0.5 bg-white/5 text-slate-300 rounded border border-white/5">
                        {day.slice(0, 3)}
                      </span>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </section>
        </div>

        {/* Right Column: Classrooms & Constraints */}
        <div className="space-y-8">
          {/* Classrooms Card */}
          <section className="glass p-6 sm:p-7 rounded-3xl border border-white/10 shadow-xl">
            <div className="flex items-center justify-between mb-5">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center border border-emerald-500/30">
                  <MapPin size={20} />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-white">Classrooms & Facilities</h3>
                  <p className="text-xs text-slate-400">{classrooms.length} venues mapped</p>
                </div>
              </div>
            </div>

            {/* Quick Add Suggested Rooms */}
            <div className="mb-4 flex flex-wrap gap-2 items-center">
              <span className="text-[11px] font-semibold text-slate-400 flex items-center gap-1">
                <Sparkles size={12} className="text-emerald-400" /> Suggested:
              </span>
              {['Central Library Hall', 'AI & Computing Lab', 'Chemistry Lab', 'Room 101', 'Room 102'].map(r => (
                <button
                  key={r}
                  onClick={() => handleAddClassroomLocal(r)}
                  disabled={classrooms.includes(r)}
                  className={`text-[10px] px-2.5 py-1 rounded-lg border font-medium transition-all ${
                    classrooms.includes(r)
                      ? 'bg-emerald-500/10 text-emerald-300 border-emerald-500/30 cursor-default opacity-60'
                      : 'bg-white/5 hover:bg-emerald-600/20 text-slate-300 hover:text-white border-white/10 hover:border-emerald-500/40'
                  }`}
                >
                  {classrooms.includes(r) ? '✓ ' : '+ '}{r}
                </button>
              ))}
            </div>
            
            <div className="flex gap-2 mb-4">
              <input 
                type="text" 
                value={newClassroom}
                onChange={(e) => setNewClassroom(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleAddClassroomLocal()}
                placeholder="Room / Hall Name (e.g. Central Library Hall)..."
                className="flex-1 bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 outline-none focus:border-emerald-500/50 transition-all text-sm placeholder:text-slate-500 text-white"
              />
              <button 
                onClick={() => handleAddClassroomLocal()}
                className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl font-bold text-xs transition-all flex items-center gap-1.5 shrink-0 shadow-lg shadow-emerald-600/20"
              >
                <Plus size={16} /> Add
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-h-48 overflow-y-auto pr-1 custom-scrollbar">
              {classrooms.map((room, i) => {
                const isLib = room.toLowerCase().includes('library');
                return (
                  <div key={room} className="p-3 bg-white/[0.03] hover:bg-white/[0.06] rounded-2xl border border-white/5 flex items-center justify-between group transition-all">
                    <div className="flex items-center gap-2.5">
                      <div className={`w-7 h-7 rounded-lg flex items-center justify-center font-bold text-xs ${
                        isLib ? 'bg-amber-500/20 text-amber-300' : 'bg-emerald-500/20 text-emerald-300'
                      }`}>
                        {isLib ? '📚' : i + 1}
                      </div>
                      <span className="text-xs font-semibold text-slate-200">{room}</span>
                    </div>
                    <button 
                      onClick={() => onRemoveClassroom(room)}
                      className="text-slate-500 hover:text-red-400 p-1 rounded-lg hover:bg-red-500/10 transition-all opacity-60 group-hover:opacity-100"
                      title="Remove Classroom"
                    >
                      <Trash2 size={14} />
                    </button>
                  </div>
                );
              })}
            </div>
          </section>

          {/* Scheduling Rules & Constraints */}
          <section className="glass p-6 sm:p-7 rounded-3xl border border-white/10 shadow-xl">
            <div className="flex items-center justify-between mb-5">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center border border-amber-500/30">
                  <Clock size={20} />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-white">Scheduling Policy & Constraints</h3>
                  <p className="text-xs text-slate-400">Full-fill workload with 2-3 free periods</p>
                </div>
              </div>
              <span className="px-3 py-1 bg-amber-500/20 text-amber-300 border border-amber-500/30 rounded-full text-[11px] font-bold">
                12:45 - 1:30 PM Lunch Break
              </span>
            </div>
            
            <div className="space-y-3">
              {[
                { 
                  label: 'Mandatory 12:45 PM to 01:30 PM Lunch & Recess Break', 
                  locked: true, 
                  note: 'Institutional break strictly locked with zero lectures across all batches.' 
                },
                { 
                  label: 'Full-Fill Schedule: 32 Active Classes, Only 2 to 3 Free Periods', 
                  locked: true, 
                  note: 'Guarantees maximum academic coverage across all 5 weekdays.' 
                },
                { 
                  label: 'Include Central Library & Research Sessions', 
                  locked: false,
                  note: 'Allocates designated weekly hours in Central Library Hall.'
                },
                { 
                  label: 'Strict Teacher-to-Subject Binding', 
                  locked: false,
                  note: 'Ensures mathematics, physics, computing & library faculty are strictly respected.'
                },
                { 
                  label: 'Automated Student Dispatch on Free Slots (Email & SMS)', 
                  locked: false 
                }
              ].map((constraint, i) => (
                <label key={i} className={`flex items-start gap-3.5 p-3.5 rounded-2xl border transition-all ${
                  constraint.locked 
                    ? 'bg-amber-500/10 border-amber-500/30 text-amber-200' 
                    : 'bg-white/[0.03] border-white/5 cursor-pointer hover:bg-white/[0.06]'
                }`}>
                  <div className="relative flex items-center mt-0.5">
                    <input 
                      type="checkbox" 
                      className="peer appearance-none w-5 h-5 rounded-lg border-2 border-slate-600 checked:bg-blue-600 checked:border-blue-600 transition-all" 
                      defaultChecked={true} 
                      disabled={constraint.locked}
                    />
                    <CheckCircle2 className="absolute left-0.5 text-white opacity-0 peer-checked:opacity-100 transition-all" size={16} />
                  </div>
                  <div>
                    <span className="text-xs font-semibold text-slate-200">{constraint.label}</span>
                    {constraint.note && (
                      <p className="text-[11px] text-slate-400 font-mono mt-0.5">{constraint.note}</p>
                    )}
                  </div>
                </label>
              ))}
            </div>
          </section>

          {/* Generate Timetable Button */}
          <button 
            onClick={onGenerate}
            className="w-full py-5 bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 text-white rounded-2xl font-bold text-base shadow-xl shadow-blue-600/25 hover:shadow-blue-600/45 transition-all hover:-translate-y-0.5 flex items-center justify-center gap-2"
          >
            <Sparkles size={20} />
            Generate Full-Fill Timetable (with Library & AI Agents)
          </button>
        </div>
      </div>
    </div>
  );
}
