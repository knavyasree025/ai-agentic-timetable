/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useCallback, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import Sidebar from './components/Sidebar';
import TopNav from './components/TopNav';
import Landing from './components/screens/Landing';
import InputPage from './components/screens/InputPage';
import AgentDashboard from './components/screens/AgentDashboard';
import TimetablePage from './components/screens/TimetablePage';
import ConflictPage from './components/screens/ConflictPage';
import SettingsPage from './components/screens/SettingsPage';
import { Screen, Teacher, TimetableEntry, Conflict, AdminProfile, AlertSettings, StudentAlert } from './types';
import { 
  DAYS, 
  TIME_SLOTS, 
  BREAK_TIME_SLOT,
  MOCK_TEACHERS, 
  MOCK_TIMETABLE, 
  MOCK_CONFLICTS, 
  DEFAULT_ADMIN, 
  DEFAULT_ALERT_SETTINGS, 
  INITIAL_STUDENT_ALERTS 
} from './constants';

export default function App() {
  const [activeScreen, setActiveScreen] = useState<Screen>('landing');
  const [subjects, setSubjects] = useState<string[]>([
    'Mathematics', 
    'Physics & Electronics', 
    'English Literature', 
    'Computer Science & AI', 
    'Library & Research', 
    'Chemistry & Materials'
  ]);
  const [teachers, setTeachers] = useState<Teacher[]>(MOCK_TEACHERS);
  const [classrooms, setClassrooms] = useState<string[]>([
    'Room 101', 
    'Room 102', 
    'Room 103', 
    'AI & Computing Lab', 
    'Central Library Hall', 
    'Chemistry Lab'
  ]);
  const [timetable, setTimetable] = useState<TimetableEntry[]>(MOCK_TIMETABLE);
  const [conflicts, setConflicts] = useState<Conflict[]>(MOCK_CONFLICTS);
  const [isGenerating, setIsGenerating] = useState(false);

  // Admin and Notification State
  const [admin, setAdmin] = useState<AdminProfile>(DEFAULT_ADMIN);
  const [alertSettings, setAlertSettings] = useState<AlertSettings>(DEFAULT_ALERT_SETTINGS);
  const [alerts, setAlerts] = useState<StudentAlert[]>(INITIAL_STUDENT_ALERTS);

  const handleSendAlert = useCallback((newAlertData: Omit<StudentAlert, 'id' | 'sentAt' | 'status'>) => {
    const newAlert: StudentAlert = {
      ...newAlertData,
      id: `alert-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
      sentAt: 'Just now',
      status: 'delivered'
    };
    setAlerts(prev => [newAlert, ...prev]);
  }, []);

  const handleClearAlerts = useCallback(() => {
    setAlerts([]);
  }, []);

  const generateTimetable = useCallback(() => {
    setIsGenerating(true);
    const newTimetable: TimetableEntry[] = [];
    const newConflicts: Conflict[] = [];

    // Consistent distinct colors
    const colorMap: Record<string, string> = {
      'Mathematics': 'bg-blue-500/20 text-blue-300 border-blue-500/50',
      'Physics': 'bg-cyan-500/20 text-cyan-300 border-cyan-500/50',
      'Physics & Electronics': 'bg-cyan-500/20 text-cyan-300 border-cyan-500/50',
      'English Literature': 'bg-emerald-500/20 text-emerald-300 border-emerald-500/50',
      'English': 'bg-emerald-500/20 text-emerald-300 border-emerald-500/50',
      'Computer Science': 'bg-purple-500/20 text-purple-300 border-purple-500/50',
      'Computer Science & AI': 'bg-purple-500/20 text-purple-300 border-purple-500/50',
      'Artificial Intelligence': 'bg-violet-500/20 text-violet-300 border-violet-500/50',
      'Library': 'bg-amber-500/20 text-amber-300 border-amber-500/50',
      'Library & Research': 'bg-amber-500/20 text-amber-300 border-amber-500/50',
      'Chemistry & Materials': 'bg-rose-500/20 text-rose-300 border-rose-500/50',
    };

    const fallbackColors = [
      'bg-blue-500/20 text-blue-300 border-blue-500/50',
      'bg-cyan-500/20 text-cyan-300 border-cyan-500/50',
      'bg-emerald-500/20 text-emerald-300 border-emerald-500/50',
      'bg-purple-500/20 text-purple-300 border-purple-500/50',
      'bg-amber-500/20 text-amber-300 border-amber-500/50',
      'bg-rose-500/20 text-rose-300 border-rose-500/50',
    ];

    // Non-break slots: 7 slots per day (total 35 in a 5-day week)
    const nonBreakSlots = TIME_SLOTS.filter(slot => slot !== BREAK_TIME_SLOT);
    
    // Choose EXACTLY 2 or 3 slots across the ENTIRE week to be free slots
    const allWeekSlots: Array<{ day: string; time: string }> = [];
    DAYS.forEach(day => {
      nonBreakSlots.forEach(time => {
        allWeekSlots.push({ day, time });
      });
    });

    // Pick 2 or 3 afternoon slots to be designated free periods
    const candidateFreeSlots = allWeekSlots.filter(s => s.time === '03:30 PM' || s.time === '02:30 PM');
    const shuffledCandidates = [...candidateFreeSlots].sort(() => Math.random() - 0.5);
    const chosenFreeSlots = shuffledCandidates.slice(0, 3); // EXACTLY 3 free slots total across the week

    let subjectIndex = 0;
    const activeSubjects = subjects.length > 0 ? subjects : ['Mathematics', 'Physics & Electronics', 'English Literature', 'Computer Science & AI', 'Library & Research'];

    DAYS.forEach(day => {
      TIME_SLOTS.forEach(time => {
        if (time === BREAK_TIME_SLOT) {
          // Strictly reserved as Break for all batches - No classes scheduled
          return;
        }

        // Check if this is one of the 2-3 designated free slots
        const isFree = chosenFreeSlots.some(s => s.day === day && s.time === time);

        if (!isFree) {
          // Get balanced subject
          const subject = activeSubjects[subjectIndex % activeSubjects.length];
          subjectIndex++;

          // Find teacher neatly assigned to this subject
          const matchingTeacher = teachers.find(t => 
            t.subject.toLowerCase().includes(subject.toLowerCase()) || 
            subject.toLowerCase().includes(t.subject.toLowerCase())
          );
          const teacherName = matchingTeacher ? matchingTeacher.name : (teachers[subjectIndex % teachers.length]?.name || 'Faculty Staff');

          // Assign room: if library, pick Library Hall; if Lab, pick Lab room
          let room = classrooms[0] || 'Room 101';
          if (subject.toLowerCase().includes('library')) {
            room = classrooms.find(r => r.toLowerCase().includes('library')) || 'Central Library Hall';
          } else if (subject.toLowerCase().includes('computer') || subject.toLowerCase().includes('ai')) {
            room = classrooms.find(r => r.toLowerCase().includes('lab') || r.toLowerCase().includes('ai')) || 'AI & Computing Lab';
          } else if (subject.toLowerCase().includes('chemistry')) {
            room = classrooms.find(r => r.toLowerCase().includes('chem')) || 'Chemistry Lab';
          } else {
            const standardRooms = classrooms.filter(r => !r.toLowerCase().includes('library'));
            room = standardRooms.length > 0 ? standardRooms[subjectIndex % standardRooms.length] : (classrooms[0] || 'Room 101');
          }

          const color = colorMap[subject] || fallbackColors[activeSubjects.indexOf(subject) % fallbackColors.length];

          newTimetable.push({
            day,
            time,
            subject,
            teacher: teacherName,
            room,
            color
          });
        }
      });
    });

    // Detect potential conflicts
    const roomUsage: Record<string, number> = {};
    newTimetable.forEach(entry => {
      const key = `${entry.day}-${entry.time}-${entry.room}`;
      roomUsage[key] = (roomUsage[key] || 0) + 1;
      if (roomUsage[key] > 1) {
        newConflicts.push({
          id: `conf-${Date.now()}-${Math.random()}`,
          type: 'clash',
          description: `${entry.room} is double-booked at ${entry.time} on ${entry.day}.`,
          severity: 'high',
          suggestions: [`Move to alternative room`, `Reschedule ${entry.subject} to free period`]
        });
      }
    });

    // Auto-generate student email & message alerts for free periods if enabled!
    if (alertSettings.autoSendOnNoClass && chosenFreeSlots.length > 0) {
      const channels: ('email' | 'sms' | 'whatsapp')[] = [];
      if (alertSettings.sendEmail) channels.push('email');
      if (alertSettings.sendSMS) channels.push('sms');
      if (alertSettings.sendWhatsApp) channels.push('whatsapp');

      const sampleFree = chosenFreeSlots[0];
      const autoAlert: StudentAlert = {
        id: `auto-alert-${Date.now()}`,
        type: 'no_class',
        day: sampleFree.day,
        time: sampleFree.time,
        channels,
        recipientsCount: 145,
        sentAt: 'Just now',
        title: `Auto-Alert: Free Period on ${sampleFree.day} @ ${sampleFree.time}`,
        content: `Official notice from Admin ${admin.name}: No regular lecture on ${sampleFree.day} at ${sampleFree.time} (Free study / Library period). Sent automatically via Email and SMS to all enrolled students.`,
        status: 'delivered',
        studentGroup: 'All Academic Batches'
      };

      setAlerts(prev => [autoAlert, ...prev]);
    }

    setTimetable(newTimetable);
    setConflicts(newConflicts);
    
    // Simulate generation delay
    setTimeout(() => {
      setIsGenerating(false);
    }, 2400);
  }, [subjects, teachers, classrooms, alertSettings, admin.name]);

  const handleAddSubject = (subject: string) => {
    if (subject && !subjects.includes(subject)) {
      setSubjects(prev => [...prev, subject]);
    }
  };

  const handleRemoveSubject = (subject: string) => {
    setSubjects(prev => prev.filter(s => s !== subject));
  };

  const handleAddTeacher = (teacher: Teacher) => {
    setTeachers(prev => [...prev, teacher]);
  };

  const handleRemoveTeacher = (id: string) => {
    setTeachers(prev => prev.filter(t => t.id !== id));
  };

  const handleAddClassroom = (room: string) => {
    if (room && !classrooms.includes(room)) {
      setClassrooms(prev => [...prev, room]);
    }
  };

  const handleRemoveClassroom = (room: string) => {
    setClassrooms(prev => prev.filter(r => r !== room));
  };

  const resolveConflict = (id: string) => {
    setConflicts(prev => prev.filter(c => c.id !== id));
  };

  const renderScreen = () => {
    switch (activeScreen) {
      case 'landing':
        return <Landing onStart={() => setActiveScreen('input')} />;
      case 'input':
        return (
          <InputPage 
            subjects={subjects} 
            onAddSubject={handleAddSubject} 
            onRemoveSubject={handleRemoveSubject}
            teachers={teachers}
            onAddTeacher={handleAddTeacher}
            onRemoveTeacher={handleRemoveTeacher}
            classrooms={classrooms}
            onAddClassroom={handleAddClassroom}
            onRemoveClassroom={handleRemoveClassroom}
            onGenerate={() => {
              generateTimetable();
              setActiveScreen('dashboard');
            }}
          />
        );
      case 'dashboard':
        return (
          <AgentDashboard 
            isGenerating={isGenerating} 
            onComplete={() => setActiveScreen('timetable')} 
            admin={admin}
          />
        );
      case 'timetable':
        return (
          <TimetablePage 
            timetable={timetable} 
            admin={admin}
            alertSettings={alertSettings}
            onRegenerate={generateTimetable} 
            onSendAlert={handleSendAlert}
          />
        );
      case 'conflicts':
        return <ConflictPage conflicts={conflicts} onResolve={resolveConflict} />;
      case 'settings':
        return (
          <SettingsPage 
            teachers={teachers} 
            onAddTeacher={handleAddTeacher} 
            onRemoveTeacher={handleRemoveTeacher} 
            admin={admin}
            onUpdateAdmin={setAdmin}
            alertSettings={alertSettings}
            onUpdateAlertSettings={setAlertSettings}
            alerts={alerts}
            onSendTestAlert={handleSendAlert}
          />
        );
      default:
        return <Landing onStart={() => setActiveScreen('input')} />;
    }
  };

  return (
    <div className="flex min-h-screen bg-slate-950 text-slate-100 selection:bg-blue-500/30 font-sans">
      {/* Sidebar */}
      {activeScreen !== 'landing' && (
        <Sidebar activeScreen={activeScreen} onNavigate={setActiveScreen} />
      )}

      <main className="flex-1 flex flex-col min-w-0">
        {activeScreen !== 'landing' && (
          <TopNav 
            admin={admin} 
            alerts={alerts} 
            alertSettings={alertSettings}
            onOpenSettings={() => setActiveScreen('settings')}
            onClearAlerts={handleClearAlerts}
            onSendInstantAlert={handleSendAlert}
          />
        )}
        
        <div className="flex-1 relative">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeScreen}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.25, ease: 'easeInOut' }}
              className="h-full"
            >
              {renderScreen()}
            </motion.div>
          </AnimatePresence>
        </div>

        {/* Footer for landing page */}
        {activeScreen === 'landing' && (
          <footer className="p-8 text-center text-slate-500 text-sm border-t border-white/5 bg-black/20 flex items-center justify-center gap-4">
            <p>© 2026 Agentic AI Timetable Generation System • Admin: <span className="text-slate-300 font-semibold">{admin.name}</span></p>
          </footer>
        )}
      </main>
    </div>
  );
}
